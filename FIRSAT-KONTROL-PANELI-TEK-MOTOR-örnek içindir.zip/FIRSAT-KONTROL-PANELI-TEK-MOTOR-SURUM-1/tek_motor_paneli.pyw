"""FIRSAT-KONTROL PANELİ — tek analiz motorlu Windows masaüstü paneli."""
from __future__ import annotations

import json
import os
import ctypes
import logging
import math
import struct
import tempfile
import wave
from logging.handlers import RotatingFileHandler
import hashlib
import queue
import subprocess
import sys
import threading
import time
import tkinter as tk
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from tkinter import font as tkfont, messagebox, ttk
from typing import Any

from radar_core import (
    APP_VERSION, DATA_DIR, LOG_DIR, ROOT, RUN_DIR, atomic_json, load_json, utc_now,
    assess_btc_strong_opportunity_gate,
)
from ortak_piyasa import SETTINGS_PATH
from tek_motor_evreni import load_local_btcturk_symbols, update_local_btcturk_list
from sinyal_kaydi import historical_summary

STATE_PATH = DATA_DIR / "binance_state.json"
STOP_PATH = RUN_DIR / "single_engine_stop.flag"
REFRESH_PATH = RUN_DIR / "single_engine_refresh.flag"
LOCAL_LIST_PATH = DATA_DIR / "btcturk_usdt_spot.json"
STRONG_PHASES = {"B", "C"}
PHASE_LABELS = {
    "A": "Kırmızı — erken hazırlık",
    "B": "Sarı — ilk doğrulama",
    "C": "Yeşil — devamlılık",
}
STATUS_COLORS = {
    "red": "#E53935", "yellow": "#FBC02D", "blue": "#1E88E5",
    "green": "#43A047", "lilac": "#AB47BC", "turquoise": "#00ACC1",
    "navy": "#3949AB",
}
PHASE_COLORS = {"A": STATUS_COLORS["red"], "B": STATUS_COLORS["yellow"], "C": STATUS_COLORS["green"]}
FINAL_DECISIONS = {
    "GÜÇLÜ FIRSAT", "ERKEN ADAY", "KIRILIM BEKLENİYOR",
    "İZLEMEDE", "FIRSAT GEÇERSİZ", "İŞLEM YOK",
}


def _theme_for_brightness(value: int) -> dict[str, str]:
    """Build a neutral gray surface palette without changing signal/status colors."""
    level = max(0, min(100, int(value)))
    shade = round(145 + (level * 0.65))
    background = f"#{shade:02X}{shade:02X}{shade:02X}"
    panel_shade = min(242, shade + 12)
    panel_alt_shade = max(92, shade - 10)
    field_shade = min(250, shade + 22)
    return {
        "background": background,
        "panel": f"#{panel_shade:02X}{panel_shade:02X}{panel_shade:02X}",
        "panel_alt": f"#{panel_alt_shade:02X}{panel_alt_shade:02X}{panel_alt_shade:02X}",
        "field": f"#{field_shade:02X}{field_shade:02X}{field_shade:02X}",
        "text": "#222222",
        "muted": "#444444",
        "border": "#FFFFFF",
        "accent": STATUS_COLORS["red"],
        "accent_active": "#E53935",
        "selection": STATUS_COLORS["navy"],
        "scrollbar": "#777777",
        "stale": STATUS_COLORS["blue"],
    }


def _opportunity_score_value(row: dict[str, Any]) -> float | None:
    """Read an explicit, finite opportunity score from 0 to 100."""
    for key in ("opportunity_score", "score_0_100"):
        value = row.get(key)
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            score = float(value)
            if math.isfinite(score) and 0.0 <= score <= 100.0:
                return score
    return None


def _opportunity_score_text(row: dict[str, Any]) -> str:
    if row.get("data_freshness") != "CANLI AKIŞ GÜNCEL":
        return "—"
    score = _opportunity_score_value(row)
    return f"{score:g}" if score is not None else "—"


def _final_decision_text(row: dict[str, Any]) -> str:
    """Use only a fresh, explicit engine decision; never infer it from A/B/C."""
    if row.get("data_freshness") != "CANLI AKIŞ GÜNCEL":
        return "KARAR BEKLENİYOR"
    raw = row.get("final_decision") or row.get("decision_class")
    decision = " ".join(str(raw or "").strip().upper().split())
    if decision not in FINAL_DECISIONS:
        return "KARAR BEKLENİYOR"
    if decision == "GÜÇLÜ FIRSAT":
        score = _opportunity_score_value(row)
        if not (
            score is not None and score >= 80
            and row.get("phase") in ("B", "C")
            and row.get("strong_alarm_eligible") is True
            and row.get("strong_opportunity_qualified") is True
        ):
            return "KARAR BEKLENİYOR"
    return decision


def _initial_panel_geometry(screen_width: int, screen_height: int) -> tuple[int, int, int, int]:
    """Return an 80%-width window with a 12% height margin."""
    width = max(1, int(screen_width))
    height = max(1, int(screen_height))
    window_width = int(width * 0.80) if width >= 1200 else int(width * 0.90)
    window_width = max(1, min(width, window_width))
    # Reserve extra room for Windows title-bar/frame decorations and the taskbar.
    window_height = max(1, min(height, int(height * 0.88)))
    x = 0
    y = max(0, (height - window_height) // 2)
    return window_width, window_height, x, y


THEME = _theme_for_brightness(65)


class RoundedButton(tk.Canvas):
    """Compact rounded action button matching the original dashboard styling."""

    def __init__(self, master: tk.Misc, *, text: str, command: Any, background: str,
                 accent: str = THEME["accent"], hover: str = THEME["accent_active"],
                 foreground: str = "#FFFFFF", font: tuple[Any, ...] = ("Segoe UI", 11, "bold"),
                 padx: int = 9, height: int = 30, state: str = "normal"):
        self._text, self._command = str(text), command
        self._background, self._accent, self._hover = background, accent, hover
        self._foreground = foreground
        self._font = tkfont.Font(root=master.winfo_toplevel(), font=font)
        self._width = max(42, int(self._font.measure(self._text)) + 2 * int(padx))
        self._height, self._state = max(20, int(height)), state
        self._hovering = self._pressed = False
        super().__init__(master, width=self._width, height=self._height, background=background,
                         borderwidth=0, highlightthickness=1, highlightbackground=background,
                         highlightcolor="#FBC02D", relief="flat", takefocus=True, cursor="hand2")
        self._draw()
        self.bind("<Enter>", self._on_enter)
        self.bind("<Leave>", self._on_leave)
        self.bind("<ButtonPress-1>", self._on_press)
        self.bind("<ButtonRelease-1>", self._on_release)
        self.bind("<Return>", self._on_keyboard_activate)
        self.bind("<space>", self._on_keyboard_activate)
        self.bind("<FocusIn>", self._on_focus_in)
        self.bind("<FocusOut>", self._on_focus_out)

    def cget(self, key: str) -> Any:
        if key == "text": return self._text
        if key == "state": return self._state
        return super().cget(key)

    def __getitem__(self, key: str) -> Any:
        return self.cget(key)

    def configure(self, cnf: Any = None, **kwargs: Any) -> Any:
        redraw = False
        if "state" in kwargs:
            self._state = str(kwargs.pop("state")); redraw = True
        if "text" in kwargs:
            self._text = str(kwargs.pop("text"))
            self._width = max(42, int(self._font.measure(self._text)) + 24)
            super().configure(width=self._width); redraw = True
        result = super().configure(cnf, **kwargs) if (cnf is not None or kwargs) else None
        if redraw: self._draw()
        return result

    config = configure

    def invoke(self) -> Any:
        if self._state != "disabled" and callable(self._command):
            return self._command()
        return None

    def set_colors(self, *, accent: str, hover: str, foreground: str = "#FFFFFF") -> None:
        self._accent, self._hover, self._foreground = accent, hover, foreground
        self._draw()

    def _draw(self) -> None:
        self.delete("all")
        color = (THEME["panel_alt"] if self._state == "disabled"
                 else self._hover if self._hovering and not self._pressed else self._accent)
        foreground = THEME["muted"] if self._state == "disabled" else self._foreground
        inset, top, bottom = 1, 1, self._height - 1
        cap = min(self._height - 2, self._width)
        self.create_oval(inset, top, inset + cap, bottom, fill=color, outline=color)
        self.create_oval(self._width-inset-cap, top, self._width-inset, bottom, fill=color, outline=color)
        self.create_rectangle(inset+cap/2, top, self._width-inset-cap/2, bottom, fill=color, outline=color)
        self.create_text(self._width/2, self._height/2+1, text=self._text,
                         fill=foreground, font=self._font, anchor="center")

    def _on_enter(self, _event: tk.Event[Any]) -> None:
        self._hovering = True; self._draw()

    def _on_leave(self, _event: tk.Event[Any]) -> None:
        self._hovering = False; self._pressed = False; self._draw()

    def _on_press(self, _event: tk.Event[Any]) -> None:
        if self._state != "disabled":
            self.focus_set(); self._pressed = True; self._draw()

    def _on_release(self, event: tk.Event[Any]) -> None:
        should_invoke = (self._state != "disabled" and self._pressed
                         and 0 <= event.x <= self._width and 0 <= event.y <= self._height)
        self._pressed = False; self._draw()
        if should_invoke: self.invoke()

    def _on_keyboard_activate(self, _event: tk.Event[Any]) -> str:
        self.invoke(); return "break"

    def _on_focus_in(self, _event: tk.Event[Any]) -> None:
        self.configure(highlightbackground="#F2C94C")

    def _on_focus_out(self, _event: tk.Event[Any]) -> None:
        self.configure(highlightbackground=self._background)


def _configure_panel_logger(log_dir: Path) -> logging.Logger:
    """Keep UI and worker stdout/stderr diagnostics in a rotating log file."""
    log_path = (Path(log_dir) / "tek_motor_paneli.log").resolve(strict=False)
    key = hashlib.sha256(str(log_path).casefold().encode("utf-8")).hexdigest()[:16]
    logger = logging.getLogger(f"firsat_kontrol_paneli.ui.{key}")
    logger.setLevel(logging.INFO)
    logger.propagate = False
    if not logger.handlers:
        try:
            log_path.parent.mkdir(parents=True, exist_ok=True)
            handler = RotatingFileHandler(
                log_path, maxBytes=2_000_000, backupCount=3, encoding="utf-8"
            )
            handler.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(message)s"))
            logger.addHandler(handler)
        except OSError:
            # Diagnostics must not prevent the panel from starting on a read-only folder.
            logger.addHandler(logging.NullHandler())
    return logger


def _now_clock() -> str:
    return datetime.now().astimezone().strftime("%H:%M:%S")


def _python_console_exe() -> str:
    exe = Path(sys.executable)
    if exe.name.casefold() == "pythonw.exe":
        candidate = exe.with_name("python.exe")
        if candidate.exists():
            return str(candidate)
    return str(exe)


def _discovery_path(row: dict[str, Any]) -> str:
    assessments = row.get("timeframes")
    if not isinstance(assessments, dict):
        assessments = {}
    early = False
    volume = False
    breakout = False
    relative = row.get("relative_strength_vs_btc_pct_points")
    relative_positive = isinstance(relative, dict) and any(
        isinstance(value, (int, float)) and value > 0 for value in relative.values()
    )
    for assessment in assessments.values():
        if not isinstance(assessment, dict):
            continue
        metrics = assessment.get("metrics")
        if not isinstance(metrics, dict):
            continue
        early = early or any(metrics.get(key) is True for key in ("compression", "rising_lows", "near_resistance"))
        volume = volume or metrics.get("volume_unusual") is True
        close = metrics.get("close")
        level = metrics.get("breakout_level")
        closed_breakout = (
            isinstance(close, (int, float)) and not isinstance(close, bool)
            and isinstance(level, (int, float)) and not isinstance(level, bool)
            and math.isfinite(float(close)) and math.isfinite(float(level))
            and float(close) > float(level)
            and metrics.get("directional_structure") is True
            and metrics.get("volume_unusual") is True
        )
        confirmed_continuity = (
            metrics.get("continuity") is True
            and metrics.get("continuity_volume_confirmed") is True
        )
        breakout = breakout or closed_breakout or confirmed_continuity
    pathways = []
    if early:
        pathways.append("Erken güçlenme")
    if volume:
        pathways.append("Olağan dışı hacim")
    if relative_positive:
        pathways.append("Göreceli güç")
    if breakout:
        pathways.append("Kırılım/devam")
    return " + ".join(pathways) if pathways else "İnceleme"


def _btc_market_context_summary(context: Any, *, current: bool) -> str:
    """Render a compact BTC direction/level summary without leaking stale prices."""
    if not current:
        return "BTC piyasa bağlamı eski/eksik — yön, destek/direnç ve kanal seviyeleri güncel kabul edilmiyor."
    if not isinstance(context, dict):
        return "BTC piyasa bağlamı henüz mevcut değil."

    timeframe_rows = context.get("timeframes")
    timeframe_rows = timeframe_rows if isinstance(timeframe_rows, dict) else {}

    def price(value: Any) -> str:
        if not isinstance(value, (int, float)) or isinstance(value, bool):
            return "—"
        try:
            number = float(value)
            return f"{number:.7g}" if math.isfinite(number) and number > 0 else "—"
        except (TypeError, ValueError, OverflowError):
            return "—"

    def zone_text(value: Any) -> str:
        if not isinstance(value, dict):
            return "teyit yok"
        lower, upper = price(value.get("lower")), price(value.get("upper"))
        center = price(value.get("center"))
        if lower != "—" and upper != "—" and lower != upper:
            return f"{lower}–{upper}"
        return center

    frame_summaries = []
    for timeframe in ("1h", "4h"):
        row = timeframe_rows.get(timeframe)
        if not isinstance(row, dict) or row.get("available") is not True:
            frame_summaries.append(f"{timeframe}: bağlam eksik")
            continue
        direction = "yukarı" if row.get("bullish") is True else "yukarı teyit yok"
        support_labels = {
            "SON GÜÇLÜ DESTEK KORUNUYOR": "korunuyor",
            "GÜÇLÜ DESTEK BÖLGESİ TEST EDİLİYOR": "test",
            "SON GÜÇLÜ DESTEK KAYBEDİLDİ": "KAYIP",
            "GÜÇLÜ DESTEK TEYİDİ YOK": "teyit yok",
        }
        resistance_labels = {
            "GÜÇLÜ DİRENÇ BÖLGESİ İÇİNDE": "içinde",
            "ÜSTÜNDEKİ GÜÇLÜ DİRENÇ BEKLENİYOR": "üstte",
            "GÜÇLÜ DİRENÇ ÜSTÜNDE — DEVAMLILIK TEYİDİ GEREKİR": "aşılmış; devam teyidi bekliyor",
            "TEYİTLİ GÜÇLÜ DİRENÇ YOK": "teyit yok",
        }
        channel_labels = {
            "TEYİTLİ KANAL İÇİNDE": "içinde",
            "KANAL ALT SINIRI KAYBEDİLDİ": "alt sınır KAYIP",
            "KANAL ÜSTÜ KIRILIM ADAYI — DEVAMLILIK BEKLENİYOR": "üst kırılım; teyit bekleniyor",
            "KANAL KONUMU HESAPLANAMADI": "konum belirsiz",
        }
        support_raw = str(row.get("support_status") or "GÜÇLÜ DESTEK TEYİDİ YOK")
        resistance_raw = str(row.get("resistance_status") or "TEYİTLİ GÜÇLÜ DİRENÇ YOK")
        support_status = support_labels.get(support_raw, support_raw)
        resistance_status = resistance_labels.get(resistance_raw, resistance_raw)
        support = zone_text(row.get("latest_confirmed_support_zone"))
        resistance = zone_text(row.get("nearest_relevant_resistance_zone"))
        channel = row.get("confirmed_channel")
        channel_status_raw = str(row.get("channel_status") or "KANAL TEYİDİ YOK")
        channel_status = channel_labels.get(channel_status_raw, channel_status_raw)
        if isinstance(channel, dict) and channel.get("available") is True:
            lower, upper = price(channel.get("lower_now")), price(channel.get("upper_now"))
            channel_text = f"{lower}–{upper}" if lower != "—" and upper != "—" else "teyitli"
            channel_text += f" {channel_status}"
        else:
            channel_text = channel_status
        frame_summaries.append(
            f"{timeframe}: {direction}; destek {support} {support_status}; "
            f"direnç {resistance} {resistance_status}; kanal {channel_text}"
        )

    def brief_risk(value: str) -> str:
        timeframe = "1h" if "1h" in value else "4h" if "4h" in value else "BTC"
        lower_value = value.casefold()
        if "kanal alt sınırı" in lower_value:
            reason = "kanal alt sınırı kaybı"
        elif "destek" in lower_value and ("altında kapanış" in lower_value or "kaybedildi" in lower_value):
            reason = "destek kaybı"
        elif "oynaklık" in lower_value:
            reason = "oynaklık yüksek"
        else:
            cleaned = " ".join(value.split())
            reason = cleaned[:48] + ("…" if len(cleaned) > 48 else "")
        return f"BTC {timeframe}: {reason}"

    warnings = context.get("risk_warnings")
    warnings = [brief_risk(item) for item in warnings if isinstance(item, str) and item] if isinstance(warnings, list) else []
    quality = context.get("data_quality_warnings")
    quality = [str(item) for item in quality if isinstance(item, str) and item] if isinstance(quality, list) else []
    suffix = []
    if warnings:
        suffix.append("RİSK: " + "; ".join(warnings[:2]))
    elif context.get("data_completeness") != "TAM" and quality:
        suffix.append("VERİ: " + quality[0])
    return "BTC | " + " | ".join(frame_summaries) + (
        " | " + " | ".join(suffix) if suffix else ""
    )


def _btc_context_display_summary(
    context: Any,
    *,
    current: bool,
    freshness: str | None = None,
) -> str:
    """Show BTC structure and the shared strong-alert eligibility gate on the main panel."""
    summary = _btc_market_context_summary(context, current=current)
    gate = assess_btc_strong_opportunity_gate(
        context if isinstance(context, dict) else {},
        freshness=freshness if current else "ESKİ/EKSİK",
        require_measurements=True,
    )
    if gate["eligible"]:
        return summary + " | BTC güçlü fırsat/alarm kapısı: AÇIK"
    reasons = [item for item in gate.get("reasons", []) if isinstance(item, str) and item]
    reason_text = "; ".join(reasons[:2]) if reasons else "BTC ölçümleri yetersiz veya risk eşiği aşıldı."
    return summary + " | BTC güçlü fırsat/alarm kapısı: KAPALI — " + reason_text


def _btc_correlation_summary(row: dict[str, Any], *, current: bool) -> str:
    """Summarize BTC co-movement without exposing stale measurements as current."""
    btc_freshness = row.get("btc_market_context_freshness")
    if not current or (
        btc_freshness is not None and btc_freshness != "CANLI AKIŞ GÜNCEL"
    ):
        return "BTC canlı verisi eski/eksik; güncel korelasyon yok"
    raw = row.get("btc_return_correlation")
    if not isinstance(raw, dict):
        return "hesaplanamadı"
    summaries = []
    for timeframe, label, default_minimum in (("1h", "1 saat", 60), ("4h", "4 saat", 34)):
        assessment = raw.get(timeframe)
        if not isinstance(assessment, dict):
            summaries.append(f"{label} hesaplanamadı")
            continue
        value = assessment.get("value")
        observations = assessment.get("observations", 0)
        minimum = assessment.get("minimum_required", default_minimum)
        valid_observations = (
            isinstance(observations, int) and not isinstance(observations, bool)
            and observations >= 0
        )
        valid_minimum = (
            isinstance(minimum, int) and not isinstance(minimum, bool)
            and minimum > 0
        )
        if (
            isinstance(value, (int, float)) and not isinstance(value, bool)
            and math.isfinite(float(value)) and -1.0 <= float(value) <= 1.0
        ):
            suffix = f" ({observations} gözlem)" if valid_observations else ""
            summaries.append(f"{label} {float(value):+.2f}{suffix}")
        elif valid_observations and valid_minimum and observations < minimum:
            summaries.append(f"{label} yetersiz ({observations}/{minimum})")
        else:
            summaries.append(f"{label} hesaplanamadı")
    return "; ".join(summaries)


def _write_transfer_bundle(
    report: dict[str, Any], json_path: Path, markdown_path: Path, bundle_path: Path
) -> dict[str, Any]:
    """Create one compressed, integrity-verifiable package for support and chat transfer."""
    state = report.get("source_state")
    if not isinstance(state, dict):
        state = {}
    settings_path = Path(SETTINGS_PATH)
    settings_exists = settings_path.is_file()
    settings_parse_status = "MISSING"
    settings_parse_error: str | None = None
    settings_size_bytes: int | None = None
    settings_mtime_utc: str | None = None
    settings_sha256: str | None = None
    fan_count: int | None = None
    stable_count: int | None = None
    fan_valid = stable_valid = False
    try:
        settings_bytes = settings_path.read_bytes()
        settings_exists = True
        settings_size_bytes = len(settings_bytes)
        settings_sha256 = hashlib.sha256(settings_bytes).hexdigest()
        settings_mtime_utc = datetime.fromtimestamp(
            settings_path.stat().st_mtime, timezone.utc
        ).isoformat(timespec="seconds")
        config = json.loads(settings_bytes.decode("utf-8-sig"))
        if not isinstance(config, dict):
            settings_parse_status = "ROOT_NOT_OBJECT"
            settings_parse_error = "JSON kökü bir nesne/sözlük değil."
        else:
            fan_list = config.get("fan_token_bases_to_skip")
            stable_list = config.get("stablecoin_bases_no_strong_alarm")
            fan_valid = isinstance(fan_list, list) and bool(fan_list) and all(
                isinstance(item, str) and item.strip() for item in fan_list
            )
            stable_valid = isinstance(stable_list, list) and bool(stable_list) and all(
                isinstance(item, str) and item.strip() for item in stable_list
            )
            fan_count = len(fan_list) if fan_valid else None
            stable_count = len(stable_list) if stable_valid else None
            settings_parse_status = (
                "OK" if fan_valid and stable_valid
                else "JSON_OK_FILTERS_INVALID"
            )
    except FileNotFoundError:
        settings_exists = False
        settings_parse_status = "MISSING"
        settings_parse_error = "ayarlar.json dosyası bulunamadı."
    except UnicodeDecodeError as exc:
        settings_parse_status = "INVALID_ENCODING"
        settings_parse_error = f"{type(exc).__name__}: {exc}"[:300]
    except json.JSONDecodeError as exc:
        settings_parse_status = "INVALID_JSON"
        settings_parse_error = f"{exc.msg} (satır {exc.lineno}, sütun {exc.colno})"[:300]
    except OSError as exc:
        settings_parse_status = "READ_ERROR"
        settings_parse_error = f"{type(exc).__name__}: {exc}"[:300]

    log_path = LOG_DIR / "tek_motor_paneli.log"
    log_present = log_path.is_file()
    log_truncated = False
    if log_present:
        try:
            log_text = "\n".join(log_path.read_text(
                encoding="utf-8", errors="replace"
            ).splitlines()[-300:])
            encoded_log = log_text.encode("utf-8")
            if len(encoded_log) > 128 * 1024:
                log_text = encoded_log[-(128 * 1024):].decode("utf-8", errors="replace")
                log_truncated = True
        except OSError as exc:
            log_text = f"Günlük okunamadı: {type(exc).__name__}: {exc}"
    else:
        log_text = "Bu çalıştırmada tek_motor_paneli.log bulunamadı."
    log_text += "\n"

    diagnostic = {
        "package_version": 1,
        "application_version": APP_VERSION,
        "application": "FIRSAT-KONTROL PANELİ — Tek Motor",
        "created_at_local": datetime.now().astimezone().isoformat(timespec="seconds"),
        "report_file": json_path.name,
        "markdown_file": markdown_path.name,
        "runtime": {
            "python_version": sys.version.split()[0],
            "platform": sys.platform,
            "executable_name": Path(sys.executable).name,
            "application_root": str(ROOT.resolve(strict=False)),
        },
        "settings_file": {
            "path": str(settings_path.resolve(strict=False)),
            "exists": settings_exists,
            "size_bytes": settings_size_bytes,
            "modified_at_utc": settings_mtime_utc,
            "sha256": settings_sha256,
            "parse_status_now": settings_parse_status,
            "parse_error_now": settings_parse_error,
            "fan_token_filter_valid_now": fan_valid,
            "fan_token_list_count_now": fan_count,
            "stablecoin_filter_valid_now": stable_valid,
            "stablecoin_list_count_now": stable_count,
            "sha256_matches_engine_state": (
                settings_sha256 == state.get("settings_sha256")
                if settings_sha256 is not None and state.get("settings_sha256")
                else None
            ),
            "loaded_sha256": state.get("settings_loaded_sha256"),
            "loaded_modified_at_utc": state.get("settings_loaded_modified_at_utc"),
            "sha256_matches_loaded_engine_settings": (
                settings_sha256 == state.get("settings_loaded_sha256")
                if settings_sha256 is not None and state.get("settings_loaded_sha256")
                else None
            ),
            "changed_since_load": state.get("settings_changed_since_load"),
            "engine_warning": state.get("settings_warning"),
        },
        "engine_state": {
            key: state.get(key) for key in (
                "generated_at_utc", "generated_at_local", "status",
                "universe_generated_at_utc", "strong_alerts_enabled",
                "fan_token_filter_valid", "stablecoin_filter_valid",
                "fan_token_list_count", "stablecoin_list_count",
                "settings_path", "settings_file_exists", "settings_file_size_bytes",
                "settings_modified_at_utc", "settings_sha256",
                "settings_parse_status", "settings_parse_error",
                "settings_loaded_sha256", "settings_loaded_modified_at_utc",
                "settings_loaded_parse_status", "settings_changed_since_load",
                "settings_warning",
                "universe_warning", "alert_filter_warning", "api_warnings",
                "common_pair_count", "scan_symbol_count",
                "websocket_connected_shards", "websocket_total_shards",
            )
        },
        "log_capture": {
            "file": str(log_path.resolve(strict=False)),
            "present": log_present,
            "last_lines_limit": 300,
            "truncated_to_128_kib": log_truncated,
        },
        "transfer_instruction": (
            "Bu ZIP'in kendisini sohbete ekleyin. JSON/Markdown içeriğini açıp "
            "uzun metni kopyalayıp yapıştırmak gerekmez."
        ),
    }
    diagnostic_json = json.dumps(
        diagnostic, ensure_ascii=False, indent=2, allow_nan=False
    ).encode("utf-8")
    transfer_note = (
        "# FIRSAT-KONTROL PANELİ — Devir Notu\n\n"
        f"- Uygulama sürümü: {APP_VERSION}\n"
        "- Devir paketi şema sürümü: 1\n"
        f"- Rapor zamanı: {report.get('created_at_local', 'bilinmiyor')}\n"
        "- Bu dosyanın içindeki JSON, tam teknik rapordur; Markdown dosyası okunabilir özettir.\n"
        "- TANI_OZETI.json motorun filtre durumunu ve ayar dosyasının yolunu, "
        "okuma sonucunu ve SHA-256 özetini içerir.\n"
        "- Günlük eki en fazla son 300 satırla ve 128 KiB üst sınırıyla tutulur.\n"
        "- SHA256SUMS.txt, paketteki içerik dosyalarının bütünlük özetlerini verir.\n\n"
        "Gönderim: Yalnızca bu ZIP dosyasını sohbete ekleyin; uzun metni panoya "
        "kopyalayıp yapıştırmaya gerek yoktur.\n"
    )
    members: dict[str, bytes] = {
        f"rapor/{json_path.name}": json_path.read_bytes(),
        f"rapor/{markdown_path.name}": markdown_path.read_bytes(),
        "tani/TANI_OZETI.json": diagnostic_json,
        "tani/DEVIR_NOTU.md": transfer_note.encode("utf-8"),
        "logs/son_300_satir_tek_motor_paneli.log": log_text.encode("utf-8"),
    }
    manifest = "\n".join(
        f"{hashlib.sha256(content).hexdigest()}  {name}"
        for name, content in sorted(members.items())
    ) + "\n"
    with zipfile.ZipFile(
        bundle_path, mode="w", compression=zipfile.ZIP_DEFLATED, compresslevel=9
    ) as archive:
        for name, content in members.items():
            archive.writestr(name, content)
        archive.writestr("SHA256SUMS.txt", manifest.encode("utf-8"))
    return diagnostic


def _strong_opportunity_reason(row: dict[str, Any]) -> str | None:
    # Alerts consume the same final decision/gate output as the dashboard.
    score = _opportunity_score_value(row)
    if (
        row.get("final_decision") != "GÜÇLÜ FIRSAT"
        or row.get("strong_opportunity_qualified") is not True
        or score is None or score < 80
    ):
        return None
    phase = row.get("phase")
    if phase not in STRONG_PHASES:
        return None
    timeframe = str(row.get("phase_timeframe") or "")
    timeframes = row.get("timeframes")
    if not timeframe or not isinstance(timeframes, dict):
        return None
    assessment = timeframes.get(timeframe)
    if not isinstance(assessment, dict) or assessment.get("phase") != phase:
        return None
    metrics = assessment.get("metrics")
    if not isinstance(metrics, dict):
        return None
    if phase == "B":
        if metrics.get("directional_structure") is not True or metrics.get("volume_unusual") is not True:
            return None
        return f"{timeframe}: kapanmış mumda fiyat yapısı ve olağan dışı hacim birlikte doğrulandı."
    if metrics.get("continuity") is not True or metrics.get("continuity_volume_confirmed") is not True:
        return None
    return f"{timeframe}: önceki kırılım sonraki kapanışta korundu ve kırılım hacmi doğrulandı."


class TekMotorPanel:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title(f"FIRSAT-KONTROL PANELİ — Sürüm {APP_VERSION}")
        # Use about 80% of available width and keep a clear height margin.
        screen_width = max(1, int(self.root.winfo_screenwidth()))
        screen_height = max(1, int(self.root.winfo_screenheight()))
        window_width, window_height, window_x, window_y = _initial_panel_geometry(
            screen_width, screen_height
        )
        self.root.geometry(
            f"{window_width}x{window_height}+{window_x}+{window_y}"
        )
        self.root.minsize(
            min(window_width, max(440, int(window_width * 0.72))),
            min(window_height, max(380, int(window_height * 0.70))),
        )
        try:
            self.root.iconbitmap(str(ROOT / "firsat_kontrol.ico"))
        except (OSError, tk.TclError):
            pass

        self.process: subprocess.Popen[str] | None = None
        self.output_queue: queue.Queue[str] = queue.Queue()
        self.event_queue: queue.Queue[tuple[str, Any]] = queue.Queue()
        self.closing = False
        self._state: dict[str, Any] = {}
        self._rows_by_symbol: dict[str, dict[str, Any]] = {}
        self._active_opportunities: set[tuple[str, str]] = set()
        self._inactive_since: dict[tuple[str, str], float] = {}
        self._last_alert_reason: dict[tuple[str, str], str] = {}
        self._last_strong_keys: set[tuple[str, str]] = set()
        self._inactive_elapsed: dict[tuple[str, str], float] = {}
        self._status_is_live = False
        self._panel_logger = _configure_panel_logger(LOG_DIR)
        self._settings_path = ROOT / "ayarlar.json"
        self._audio_lock = threading.Lock()
        self._tracked_symbol: str | None = None
        self._tracked_plan: dict[str, Any] | None = None
        self._level_alert_fired: set[str] = set()
        self._last_monitored_price: float | None = None
        self._tracking_initial_baseline_set = False
        self._level_pause_reason: str | None = None
        self._start_clock = "—"
        self._stop_clock = "—"

        preferences = self._load_panel_preferences()
        try:
            saved_volume = int(preferences.get("alarm_volume", 65))
        except (TypeError, ValueError, OverflowError):
            saved_volume = 65
        saved_volume = max(0, min(100, saved_volume))
        try:
            saved_brightness = int(preferences.get("screen_brightness", 65))
        except (TypeError, ValueError, OverflowError):
            saved_brightness = 65
        saved_brightness = max(0, min(100, saved_brightness))
        self.screen_brightness_var = tk.IntVar(value=saved_brightness)
        THEME.clear()
        THEME.update(_theme_for_brightness(saved_brightness))
        self.alarm_sound_enabled_var = tk.BooleanVar(
            value=preferences.get("alarm_sound_enabled", True) is not False
        )
        self.alarm_volume_var = tk.IntVar(value=saved_volume)
        # Price-level tracking deliberately starts off on every application launch.
        self.level_tracking_enabled_var = tk.BooleanVar(value=False)

        self.engine_status = tk.StringVar(value="Binance motoru başlatılmadı.")
        self.summary = tk.StringVar(value=(
            "Başlangıç mum verileri: —\n"
            "WebSocket: —\n"
            "Geçmiş: —\n"
            "Hata: —"
        ))
        self.universe_summary = tk.StringVar(value="Yerel BtcTurk USDT listesi kontrol ediliyor.")
        self.alert_banner = tk.StringVar(value="Alarm yalnızca güncel verilerle doğrulanan güçlü fırsatlarda etkinleşir.")
        self.start_clock_var = tk.StringVar(value="Başlatma saati: —")
        self.stop_clock_var = tk.StringVar(value="Durdurma saati: —")
        self.universe_count_var = tk.StringVar(value="— parite")
        self.universe_mode_var = tk.StringVar(value="Tarama evreni henüz doğrulanmadı")
        self.universe_timestamp_var = tk.StringVar(value="—")
        self.btcturk_list_var = tk.StringVar(value="Yerel liste kontrol ediliyor.")
        self.selected_candidate_var = tk.StringVar(value="Coin seçilmedi")
        self.risk_vars = {
            "scenario": tk.StringVar(value="—"),
            "entry": tk.StringVar(value="—"),
            "breakout": tk.StringVar(value="—"),
            "stop": tk.StringVar(value="—"),
            "targets": tk.StringVar(value="—"),
            "risk": tk.StringVar(value="—"),
            "rr": tk.StringVar(value="—"),
            "status": tk.StringVar(value="Plan bekleniyor"),
        }
        self.risk_note_var = tk.StringVar(value="Giriş, stop ve hedefler yalnızca güncel ve yeterli veride gösterilir.")
        self.live_flow_var = tk.StringVar(value="motor / canlı akış: durum bekleniyor")
        self.universe_market_var = tk.StringVar(value="Binance Spot USDT")
        self.universe_pairs_var = tk.StringVar(value="parite sayısı doğrulanıyor")
        self.universe_compact_var = tk.StringVar(value=(
            "Son evren kaydı: yok · BtcTurk yerel liste durumu: kontrol ediliyor"
        ))
        self.btc_context_var = tk.StringVar(
            value="BTC piyasa bağlamı: güncel akış ve seviye teyidi bekleniyor."
        )
        self.risk_row_vars = {
            key: tk.StringVar(value="") for key in ("scenario", "breakout")
        }
        self.risk_row_widgets: dict[str, tk.Text] = {}
        for variable in self.risk_vars.values():
            variable.trace_add("write", self._sync_risk_rows)
        self._sync_risk_rows()

        self._apply_theme()
        self._build_ui()
        self._titlebar_after_id: str | None = None
        self._poll_after_id: str | None = None
        self.root.bind("<Destroy>", self._cancel_scheduled_callbacks, add="+")
        self._titlebar_after_id = self.root.after(180, self._apply_windows_titlebar_theme)
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)
        self._poll_after_id = self.root.after(750, self._poll)

    def _load_panel_preferences(self) -> dict[str, Any]:
        """Read optional UI preferences without changing the engine's existing settings."""
        try:
            if not self._settings_path.is_file():
                return {}
            with self._settings_path.open("r", encoding="utf-8") as handle:
                settings = json.load(handle)
        except (OSError, json.JSONDecodeError) as exc:
            self._append_log(f"Panel ayarları okunamadı; varsayılanlar kullanılıyor: {exc}")
            return {}
        if not isinstance(settings, dict):
            return {}
        panel_settings = settings.get("panel_ui")
        return panel_settings if isinstance(panel_settings, dict) else {}

    def _save_panel_preferences(self) -> bool:
        """Merge UI preferences into ayarlar.json; retain every unrelated engine setting."""
        try:
            if self._settings_path.is_file():
                with self._settings_path.open("r", encoding="utf-8") as handle:
                    settings = json.load(handle)
                if not isinstance(settings, dict):
                    raise ValueError("ayarlar.json üst düzeyde nesne içermiyor")
            else:
                settings = {}
            panel_settings = settings.get("panel_ui")
            if not isinstance(panel_settings, dict):
                panel_settings = {}
            panel_settings["alarm_sound_enabled"] = bool(self.alarm_sound_enabled_var.get())
            panel_settings["alarm_volume"] = max(0, min(100, int(self.alarm_volume_var.get())))
            panel_settings["screen_brightness"] = max(
                0, min(100, int(self.screen_brightness_var.get()))
            )
            settings["panel_ui"] = panel_settings
            atomic_json(self._settings_path, settings)
            return True
        except (OSError, ValueError, TypeError, json.JSONDecodeError) as exc:
            self._append_log(f"Panel ayarları kaydedilemedi; mevcut ayarlar korunuyor: {exc}")
            return False

    def _save_volume_setting(self, _event: Any = None) -> None:
        self._save_panel_preferences()

    def _save_brightness_setting(self, _event: Any = None) -> None:
        self._save_panel_preferences()

    def _apply_screen_brightness(self, _value: Any = None) -> None:
        previous = dict(THEME)
        THEME.clear()
        THEME.update(_theme_for_brightness(self.screen_brightness_var.get()))
        self._apply_theme()
        self._recolor_widget_tree(self.root, previous)
        self._refresh_alarm_controls()
        self._apply_windows_titlebar_theme()

    def _recolor_widget_tree(self, widget: tk.Misc, previous: dict[str, str]) -> None:
        """Recolor surfaces and text independently, preserving contrast when gray values overlap."""
        surface_roles = ("background", "panel", "panel_alt", "field", "selection",
                         "scrollbar", "accent", "accent_active")
        surface_map = {
            previous[role]: THEME[role]
            for role in surface_roles
            if role in previous and previous[role] != THEME[role]
        }
        text_roles = ("text", "muted")
        text_map = {
            previous[role]: THEME[role]
            for role in text_roles
            if role in previous and previous[role] != THEME[role]
        }
        if isinstance(widget, RoundedButton):
            if widget._background in surface_map:
                widget._background = surface_map[widget._background]
            if widget._accent in surface_map:
                widget._accent = surface_map[widget._accent]
            if widget._hover in surface_map:
                widget._hover = surface_map[widget._hover]
            try:
                widget.configure(background=widget._background)
            except tk.TclError:
                pass
            widget._draw()
        option_maps = {
            "background": surface_map,
            "activebackground": surface_map,
            "highlightbackground": surface_map,
            "selectbackground": surface_map,
            "troughcolor": surface_map,
            "foreground": text_map,
            "activeforeground": text_map,
            "selectforeground": text_map,
            "insertbackground": text_map,
            "disabledforeground": text_map,
        }
        for option, color_map in option_maps.items():
            try:
                old_color = widget.cget(option)
            except (tk.TclError, KeyError):
                continue
            if old_color in color_map:
                try:
                    widget.configure(**{option: color_map[old_color]})
                except tk.TclError:
                    pass
        try:
            children = widget.winfo_children()
        except tk.TclError:
            children = []
        for child in children:
            self._recolor_widget_tree(child, previous)

    def _toggle_alarm_sound(self) -> None:
        self.alarm_sound_enabled_var.set(not self.alarm_sound_enabled_var.get())
        self._refresh_alarm_controls()
        self._save_panel_preferences()
        state = "açıldı" if self.alarm_sound_enabled_var.get() else "kapatıldı"
        self._append_log(f"Güçlü fırsat ve fiyat seviyesi sesleri {state}.")

    def _test_alarm_sound(self) -> None:
        # The test button intentionally tests the chosen volume even when alerts are toggled off.
        self._play_alert_tone("test", force=True)

    def _refresh_alarm_controls(self) -> None:
        alarm_on = self.alarm_sound_enabled_var.get()
        self.alarm_sound_button.configure(text="Alarm Açık" if alarm_on else "Alarm Kapalı")
        self.alarm_sound_button.set_colors(
            accent="#D32F2F" if alarm_on else "#858585",
            hover="#E53935" if alarm_on else "#9A9A9A",
        )
        tracking_on = self.level_tracking_enabled_var.get()
        self.level_tracking_button.configure(text="Seviye Açık" if tracking_on else "Seviye Kapalı")
        self.level_tracking_button.set_colors(
            accent=STATUS_COLORS["turquoise"] if tracking_on else "#858585",
            hover="#26C6DA" if tracking_on else "#9A9A9A",
        )

    def _play_alert_tone(self, kind: str, *, force: bool = False) -> None:
        if not force and not self.alarm_sound_enabled_var.get():
            return
        volume = max(0, min(100, int(self.alarm_volume_var.get())))
        if volume <= 0:
            return
        threading.Thread(
            target=self._play_alert_tone_worker, args=(kind, volume),
            daemon=True, name=f"alert-tone-{kind}",
        ).start()

    def _play_alert_tone_worker(self, kind: str, volume: int) -> None:
        """Synthesize a short, volume-scaled WAV; Windows playback runs off the Tk thread."""
        if os.name != "nt":
            return
        patterns = {
            "strong": ((880, 0.12), (1175, 0.16)),
            "test": ((880, 0.12), (1175, 0.16)),
            "entry": ((620, 0.09), (790, 0.12)),
            "breakout": ((1040, 0.17),),
            "target": ((740, 0.09), (1050, 0.14)),
            "stop": ((390, 0.22), (290, 0.26)),
        }
        tones = patterns.get(kind, patterns["strong"])
        sample_rate = 22050
        sound_path: Path | None = None
        try:
            with self._audio_lock:
                with tempfile.NamedTemporaryFile(prefix="fkp_alarm_", suffix=".wav", delete=False) as temp:
                    sound_path = Path(temp.name)
                frames = bytearray()
                amplitude = int(32767 * (volume / 100.0) * 0.42)
                for frequency, seconds in tones:
                    frame_count = int(sample_rate * seconds)
                    for index in range(frame_count):
                        fade = min(1.0, index / 220.0, (frame_count - index) / 220.0)
                        sample = int(
                            amplitude * fade *
                            math.sin(2.0 * math.pi * frequency * index / sample_rate)
                        )
                        frames.extend(struct.pack("<h", sample))
                    frames.extend(b"\x00\x00" * int(sample_rate * 0.035))
                with wave.open(str(sound_path), "wb") as wav_file:
                    wav_file.setnchannels(1)
                    wav_file.setsampwidth(2)
                    wav_file.setframerate(sample_rate)
                    wav_file.writeframes(frames)
                import winsound
                winsound.PlaySound(str(sound_path), winsound.SND_FILENAME)
        except Exception as exc:
            self._append_log(f"Alarm sesi çalınamadı ({kind}): {exc}")
        finally:
            if sound_path is not None:
                try:
                    sound_path.unlink(missing_ok=True)
                except OSError:
                    pass

    @staticmethod
    def _positive_price(value: Any) -> float | None:
        try:
            result = float(value)
        except (TypeError, ValueError, OverflowError):
            return None
        return result if math.isfinite(result) and result > 0 else None

    def _toggle_level_tracking(self) -> None:
        if self.level_tracking_enabled_var.get():
            self._stop_level_tracking("Kullanıcı seviye takibini kapattı.")
            return
        selection = self.candidate_tree.selection()
        if not selection:
            messagebox.showwarning(
                "Seviye takibi", "Önce tabloda bir coin seçin.", parent=self.root
            )
            return
        symbol = selection[0]
        row = self._rows_by_symbol.get(symbol)
        if not isinstance(row, dict) or not self._state_is_live() or row.get("data_freshness") != "CANLI AKIŞ GÜNCEL":
            messagebox.showwarning(
                "Seviye takibi",
                "Seviye takibi yalnızca seçilen coin'in güncel canlı verisi varken başlatılabilir.",
                parent=self.root,
            )
            return
        plan = row.get("risk_plan") if isinstance(row.get("risk_plan"), dict) else {}
        low = self._positive_price(plan.get("entry_zone_low"))
        high = self._positive_price(plan.get("entry_zone_high"))
        breakout = self._positive_price(plan.get("breakout_level"))
        stop = self._positive_price(plan.get("stop_loss"))
        targets_raw = plan.get("targets") if isinstance(plan.get("targets"), list) else []
        targets = []
        for index, target in enumerate(targets_raw[:3], start=1):
            if not isinstance(target, dict):
                continue
            price = self._positive_price(target.get("price"))
            if price is not None:
                targets.append((str(target.get("name") or f"Hedef {index}"), price, index))
        if low is None or high is None or high < low or breakout is None or stop is None or not targets:
            messagebox.showwarning(
                "Seviye takibi",
                "Bu coin için geçerli giriş bölgesi, kırılım, stop ve en az bir hedef seviyesi yok.",
                parent=self.root,
            )
            return
        self._tracked_symbol = symbol
        self._tracked_plan = {
            "symbol": symbol, "entry_low": low, "entry_high": high,
            "breakout": breakout, "stop": stop, "targets": targets,
        }
        self._level_alert_fired.clear()
        self._last_monitored_price = None
        self._tracking_initial_baseline_set = False
        self._level_pause_reason = None
        self.level_tracking_enabled_var.set(True)
        self._refresh_alarm_controls()
        self.alert_banner.set(
            f"Seviye takibi başladı: {symbol}; mevcut planın fiyat seviyeleri izleniyor."
        )
        self._append_log(
            f"Seviye takibi başladı: {symbol}; plan seviyeleri sabitlendi, motor otomatik emir göndermez."
        )
        self._update_price_level_tracking()

    def _stop_level_tracking(self, reason: str) -> None:
        if self.level_tracking_enabled_var.get() or self._tracked_symbol:
            self._append_log(f"Seviye takibi kapandı: {reason}")
        self.level_tracking_enabled_var.set(False)
        self._tracked_symbol = None
        self._tracked_plan = None
        self._level_alert_fired.clear()
        self._last_monitored_price = None
        self._tracking_initial_baseline_set = False
        self._level_pause_reason = None
        if hasattr(self, "level_tracking_button"):
            self._refresh_alarm_controls()

    def _evaluate_level_crossings(self, previous: float, current: float) -> list[tuple[str, str]]:
        """Return one event per level crossing and re-arm only after price recrosses away."""
        plan = self._tracked_plan
        if not isinstance(plan, dict):
            return []
        symbol = str(plan.get("symbol") or self._tracked_symbol or "coin")
        events: list[tuple[str, str]] = []
        low, high = float(plan["entry_low"]), float(plan["entry_high"])
        was_in_entry = low <= previous <= high
        is_in_entry = low <= current <= high
        crossed_entry = (
            (not was_in_entry and is_in_entry)
            or (previous < low and current > high)
            or (previous > high and current < low)
        )
        if crossed_entry and "entry" not in self._level_alert_fired:
            self._level_alert_fired.add("entry")
            events.append((
                "entry",
                f"{symbol}: olası giriş bölgesine ulaşıldı ({low:.8g}–{high:.8g} USDT).",
            ))
        elif "entry" in self._level_alert_fired and not is_in_entry:
            self._level_alert_fired.discard("entry")

        breakout = float(plan["breakout"])
        if "breakout" in self._level_alert_fired and current < breakout:
            self._level_alert_fired.discard("breakout")
        if "breakout" not in self._level_alert_fired and previous < breakout <= current:
            self._level_alert_fired.add("breakout")
            events.append(("breakout", f"{symbol}: kırılım seviyesi aşıldı ({breakout:.8g} USDT)."))

        for name, price, target_index in plan.get("targets", []):
            key = f"target:{target_index}"
            if key in self._level_alert_fired and current < price:
                self._level_alert_fired.discard(key)
            if key not in self._level_alert_fired and previous < price <= current:
                self._level_alert_fired.add(key)
                events.append(("target", f"{symbol}: {name} seviyesine ulaşıldı ({price:.8g} USDT)."))

        stop = float(plan["stop"])
        if "stop" in self._level_alert_fired and current > stop:
            self._level_alert_fired.discard("stop")
        if "stop" not in self._level_alert_fired and previous > stop >= current:
            self._level_alert_fired.add("stop")
            events.append(("stop", f"{symbol}: zarar durdurma seviyesi görüldü ({stop:.8g} USDT)."))
        return events

    def _emit_level_alert(self, kind: str, message: str) -> None:
        self.alert_banner.set("SEVİYE ALARMI | " + message)
        self._append_log("SEVİYE ALARMI | " + message)
        self._play_alert_tone(kind)

    def _update_price_level_tracking(self) -> None:
        """Pause on stale input; after data resumes use one fresh price as a new baseline."""
        if not self.level_tracking_enabled_var.get() or not isinstance(self._tracked_plan, dict):
            return
        symbol = str(self._tracked_symbol or "")
        row = self._rows_by_symbol.get(symbol)
        if (
            not self._state_is_live()
            or not isinstance(row, dict)
            or row.get("data_freshness") != "CANLI AKIŞ GÜNCEL"
        ):
            reason = "canlı veri güncel değil"
            if self._level_pause_reason != reason:
                self._append_log(f"Seviye takibi bekletildi: {symbol} — {reason}.")
            self._level_pause_reason = reason
            self._last_monitored_price = None
            return
        current = self._positive_price(row.get("latest_price"))
        if current is None:
            reason = "geçerli fiyat verisi yok"
            if self._level_pause_reason != reason:
                self._append_log(f"Seviye takibi bekletildi: {symbol} — {reason}.")
            self._level_pause_reason = reason
            self._last_monitored_price = None
            return
        if self._level_pause_reason is not None:
            self._append_log(f"Seviye takibi yeniden başladı: {symbol} — güncel veriyle başlangıç fiyatı alındı.")
        self._level_pause_reason = None
        if self._last_monitored_price is None:
            self._last_monitored_price = current
            if not self._tracking_initial_baseline_set:
                self._tracking_initial_baseline_set = True
                plan = self._tracked_plan
                if (
                    isinstance(plan, dict)
                    and float(plan["entry_low"]) <= current <= float(plan["entry_high"])
                    and "entry" not in self._level_alert_fired
                ):
                    self._level_alert_fired.add("entry")
                    self._emit_level_alert(
                        "entry",
                        f"{symbol}: güncel fiyat mevcut olası giriş bölgesinde "
                        f"({float(plan['entry_low']):.8g}–{float(plan['entry_high']):.8g} USDT).",
                    )
            return
        previous = self._last_monitored_price
        self._last_monitored_price = current
        events = self._evaluate_level_crossings(previous, current)
        played_kinds: set[str] = set()
        for kind, message in events:
            self.alert_banner.set("SEVİYE ALARMI | " + message)
            self._append_log("SEVİYE ALARMI | " + message)
            if kind not in played_kinds:
                self._play_alert_tone(kind)
                played_kinds.add(kind)

    def _apply_theme(self) -> None:
        """Apply the active gray surface palette while preserving vivid signal colors."""
        c = THEME
        self.root.configure(background=c["background"])
        style = ttk.Style(self.root)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure(".", background=c["background"], foreground=c["text"], font=("Segoe UI", 10))
        style.configure("TFrame", background=c["background"])
        style.configure("TLabel", background=c["background"], foreground=c["text"])
        style.configure("Panel.TLabel", background=c["panel"], foreground=c["text"])
        style.configure(
            "TLabelframe", background=c["panel"], foreground=c["text"],
            bordercolor=c["border"], lightcolor=c["border"], darkcolor=c["border"],
            focuscolor=c["border"], relief="flat", borderwidth=1, padding=5,
        )
        style.configure(
            "TLabelframe.Label", background=c["panel"], foreground=c["text"],
            font=("Segoe UI", 10, "bold"),
        )
        style.configure(
            "Compact.TLabelframe", background=c["panel"], foreground=c["text"],
            bordercolor=c["border"], lightcolor=c["border"], darkcolor=c["border"],
            focuscolor=c["border"], relief="flat", borderwidth=1, padding=2,
        )
        style.configure(
            "Compact.TLabelframe.Label", background=c["panel"], foreground=c["text"],
            font=("Segoe UI", 9),
        )
        style.configure(
            "TButton", background=c["accent"], foreground="#FFFFFF",
            bordercolor=c["accent"], lightcolor=c["accent"], darkcolor=c["accent"],
            padding=(5, 2),
        )
        style.map(
            "TButton",
            background=[("active", c["accent_active"]), ("disabled", c["panel_alt"])],
            foreground=[("disabled", c["muted"])],
        )
        selected_fg = "#FFFFFF"
        style.configure(
            "Panel.Treeview", background=c["field"], fieldbackground=c["field"],
            foreground=c["text"], bordercolor=c["border"], rowheight=24,
            relief="flat", borderwidth=0, font=("Segoe UI", 10),
        )
        style.map(
            "Panel.Treeview", background=[("selected", c["selection"])],
            foreground=[("selected", selected_fg)],
        )
        style.configure(
            "Panel.Treeview.Heading", background=c["panel_alt"], foreground=c["text"],
            relief="flat", borderwidth=0, font=("Segoe UI", 9, "bold"), padding=(3, 2),
        )
        style.map("Panel.Treeview.Heading", background=[("active", c["border"])])
        for orientation in ("Vertical", "Horizontal"):
            style.configure(
                f"Slim.{orientation}.TScrollbar", troughcolor=c["panel_alt"],
                background=c["scrollbar"], darkcolor=c["scrollbar"], lightcolor=c["scrollbar"],
                bordercolor=c["panel_alt"], relief="flat", borderwidth=0,
                width=8, arrowsize=7,
            )
            style.map(
                f"Slim.{orientation}.TScrollbar",
                background=[("pressed", c["accent"]), ("active", "#999999")],
                troughcolor=[("active", c["panel_alt"])],
            )

    def _apply_windows_titlebar_theme(self) -> None:
        """Match the Windows title bar to the current gray palette when supported."""
        if os.name != "nt":
            return
        try:
            from ctypes import wintypes
            user32, dwmapi = ctypes.windll.user32, ctypes.windll.dwmapi
            user32.GetAncestor.argtypes = [wintypes.HWND, wintypes.UINT]
            user32.GetAncestor.restype = wintypes.HWND
            hwnd = user32.GetAncestor(wintypes.HWND(self.root.winfo_id()), 2)
            if not hwnd:
                hwnd = wintypes.HWND(self.root.winfo_id())
            set_attribute = dwmapi.DwmSetWindowAttribute
            set_attribute.argtypes = [wintypes.HWND, wintypes.DWORD, ctypes.c_void_p, wintypes.DWORD]
            set_attribute.restype = ctypes.c_long
            def set_value(attribute: int, value: Any) -> bool:
                return set_attribute(hwnd, attribute, ctypes.byref(value), ctypes.sizeof(value)) == 0
            shade = int(THEME["background"][1:3], 16)
            dark_mode = ctypes.c_int(1 if shade < 145 else 0)
            if not set_value(20, dark_mode):
                set_value(19, dark_mode)
            background_rgb = THEME["background"].lstrip("#")
            foreground_rgb = THEME["text"].lstrip("#")
            background_bgr = int(background_rgb[4:6] + background_rgb[2:4] + background_rgb[0:2], 16)
            foreground_bgr = int(foreground_rgb[4:6] + foreground_rgb[2:4] + foreground_rgb[0:2], 16)
            set_value(35, ctypes.c_uint32(background_bgr))
            set_value(36, ctypes.c_uint32(foreground_bgr))
        except Exception:
            return


    def _build_ui(self) -> None:
        outer = ttk.Frame(self.root, padding=6)
        outer.pack(fill="both", expand=True)
        outer.columnconfigure(0, weight=1)
        outer.rowconfigure(4, weight=1)

        # Pencere başlığı/simgesi program kimliğini taşır; içeride yinelenen büyük başlık kaldırıldı.
        header = ttk.Frame(outer)
        header.grid(row=0, column=0, sticky="ew", pady=(0, 3))
        header.columnconfigure(0, weight=1)
        self.engine_badge = tk.Label(
            header, textvariable=self.engine_status, anchor="w", justify="left",
            font=("Segoe UI", 10, "bold"), padx=8, pady=4,
            bg=THEME["panel_alt"], fg=THEME["text"], wraplength=660,
        )
        self.engine_badge.grid(row=0, column=0, sticky="ew")

        # Eylemler aynı hizada; başlatma/durdurma saatleri düğmelerinin altında kalır.
        controls = ttk.Frame(outer)
        controls.grid(row=1, column=0, sticky="ew", pady=(5, 6))
        self.update_list_button = RoundedButton(
            controls, text="Parite listesini güncelle", command=self._update_local_list,
            background=THEME["panel"], accent=THEME["accent"], hover=THEME["accent_active"],
            padx=10, height=30,
        )
        self.update_list_button.pack(side="left", padx=(0, 8))
        self.report_button = RoundedButton(
            controls, text="Rapor + Devir ZIP", command=self._create_report,
            background=THEME["panel"], accent=THEME["accent"], hover=THEME["accent_active"],
            padx=10, height=30,
        )
        self.report_button.pack(side="left", padx=(0, 8))

        self.start_group = ttk.Frame(controls)
        self.start_group.pack(side="left", padx=(0, 8))
        self.start_button = RoundedButton(
            self.start_group, text="Başlat", command=self._start_engine,
            background=THEME["panel"], accent=THEME["accent"], hover=THEME["accent_active"],
            padx=12, height=30,
        )
        self.start_button.pack()
        ttk.Label(self.start_group, textvariable=self.start_clock_var,
                  style="Panel.TLabel", font=("Segoe UI", 9), anchor="center").pack()

        self.stop_group = ttk.Frame(controls)
        self.stop_group.pack(side="left", padx=(0, 8))
        self.stop_button = RoundedButton(
            self.stop_group, text="Durdur", command=self._stop_engine,
            background=THEME["panel"], accent=THEME["accent"], hover=THEME["accent_active"],
            padx=12, height=30, state="disabled",
        )
        self.stop_button.pack()
        ttk.Label(self.stop_group, textvariable=self.stop_clock_var,
                  style="Panel.TLabel", font=("Segoe UI", 9), anchor="center").pack()

        # Two-line legend immediately right of Stop; entries stay horizontal.
        self.phase_legend = tk.Frame(
            controls, bg=THEME["panel"], highlightthickness=1,
            highlightbackground=THEME["border"], padx=7, pady=3,
        )
        self.phase_legend.pack(side="left", fill="both", expand=True, padx=(1, 0))
        legend_row1 = tk.Frame(self.phase_legend, bg=THEME["panel"])
        legend_row1.grid(row=0, column=0, columnspan=2, sticky="ew")
        legend_row2 = tk.Frame(self.phase_legend, bg=THEME["panel"])
        legend_row2.grid(row=1, column=0, columnspan=2, sticky="ew")
        tk.Label(legend_row1, text="AŞAMA / VERİ LEJANTI", bg=THEME["panel"],
                 fg=THEME["muted"], font=("Segoe UI", 11, "bold"),
                 anchor="w").pack(side="left", padx=(0, 8))
        tk.Label(legend_row1, text="A — Hazırlık", bg=THEME["panel"],
                 fg=PHASE_COLORS["A"], font=("Segoe UI", 11, "bold"),
                 anchor="w").pack(side="left", padx=(0, 8))
        tk.Label(legend_row1, text="B — Yapı + katılım kapanmış mumda", bg=THEME["panel"],
                 fg=PHASE_COLORS["B"], font=("Segoe UI", 11, "bold"),
                 anchor="w").pack(side="left")
        tk.Label(legend_row2, text="C — Devamlılık / geri test", bg=THEME["panel"],
                 fg=PHASE_COLORS["C"], font=("Segoe UI", 11, "bold"),
                 anchor="w").pack(side="left", padx=(0, 10))
        tk.Label(legend_row2, text="Mavi — eski/eksik veri", bg=THEME["panel"],
                 fg="#1E88E5", font=("Segoe UI", 10), anchor="w").pack(side="left")
        tk.Label(
            self.phase_legend, textvariable=self.live_flow_var,
            bg=THEME["panel"], fg=THEME["muted"], font=("Segoe UI", 9),
            anchor="w", justify="left", wraplength=1100,
        ).grid(row=2, column=0, columnspan=2, sticky="ew", pady=(2, 0))

        self.alert_strip = ttk.Frame(outer)
        self.alert_strip.grid(row=2, column=0, sticky="ew", pady=(0, 7))
        self.alert_strip.columnconfigure(0, weight=2)
        self.alert_strip.columnconfigure(1, weight=5)
        self.alert_label = tk.Label(
            self.alert_strip, textvariable=self.alert_banner, anchor="w", justify="left",
            font=("Segoe UI", 10, "bold"), padx=7, pady=4,
            bg=THEME["panel_alt"], fg=THEME["text"], wraplength=340,
        )
        self.alert_label.grid(row=0, column=0, sticky="nsew", padx=(0, 5))

        self.alarm_controls_frame = tk.Frame(self.alert_strip, bg=THEME["background"])
        self.alarm_controls_frame.grid(row=0, column=1, sticky="nsew")
        for column in range(5):
            self.alarm_controls_frame.columnconfigure(column, weight=1, uniform="alert-controls")

        alarm_group = tk.Frame(self.alarm_controls_frame, bg=THEME["panel"])
        alarm_group.grid(row=0, column=0, sticky="nsew", padx=1)
        alarm_group.columnconfigure(1, weight=1)
        self.alarm_sound_button = RoundedButton(
            alarm_group,
            text="Alarm Açık" if self.alarm_sound_enabled_var.get() else "Alarm Kapalı",
            command=self._toggle_alarm_sound, background=THEME["panel"],
            accent="#D32F2F" if self.alarm_sound_enabled_var.get() else "#858585",
            hover="#E53935", font=("Segoe UI", 8, "bold"), padx=3, height=23,
        )
        self.alarm_sound_button.grid(row=0, column=0, sticky="w", padx=(2, 3), pady=4)
        tk.Label(
            alarm_group, text="güçlü fırsat seslerini açar veya kapatır",
            bg=THEME["panel"], fg=THEME["muted"], font=("Segoe UI", 8),
            justify="left", anchor="w", wraplength=86,
        ).grid(row=0, column=1, sticky="ew", padx=(0, 3))

        volume_group = tk.Frame(self.alarm_controls_frame, bg=THEME["panel"])
        volume_group.grid(row=0, column=1, sticky="nsew", padx=1)
        volume_group.columnconfigure(1, weight=1)
        self.volume_scale = tk.Scale(
            volume_group, from_=0, to=100, resolution=1, orient="horizontal",
            variable=self.alarm_volume_var, showvalue=True, length=74, width=9,
            sliderlength=12, highlightthickness=0, bd=0,
            bg=THEME["panel"], fg=THEME["text"], troughcolor=THEME["panel_alt"],
            activebackground=THEME["accent_active"], font=("Segoe UI", 7),
        )
        self.volume_scale.grid(row=0, column=0, sticky="w", padx=(2, 3), pady=2)
        self.volume_scale.bind("<ButtonRelease-1>", self._save_volume_setting)
        self.volume_scale.bind("<KeyRelease>", self._save_volume_setting)
        tk.Label(
            volume_group, text="ses seviyesini ayarlar",
            bg=THEME["panel"], fg=THEME["muted"], font=("Segoe UI", 8),
            justify="left", anchor="w", wraplength=76,
        ).grid(row=0, column=1, sticky="ew", padx=(0, 3))

        test_group = tk.Frame(self.alarm_controls_frame, bg=THEME["panel"])
        test_group.grid(row=0, column=2, sticky="nsew", padx=1)
        test_group.columnconfigure(1, weight=1)
        self.test_sound_button = RoundedButton(
            test_group, text="Sesi dene", command=self._test_alarm_sound,
            background=THEME["panel"], accent="#FBC02D", hover="#FDD835",
            foreground="#222222", font=("Segoe UI", 8, "bold"), padx=3, height=23,
        )
        self.test_sound_button.grid(row=0, column=0, sticky="w", padx=(2, 3), pady=4)
        tk.Label(
            test_group, text="ses ayarını denetler",
            bg=THEME["panel"], fg=THEME["muted"], font=("Segoe UI", 8),
            justify="left", anchor="w", wraplength=76,
        ).grid(row=0, column=1, sticky="ew", padx=(0, 3))

        level_group = tk.Frame(self.alarm_controls_frame, bg=THEME["panel"])
        level_group.grid(row=0, column=3, sticky="nsew", padx=1)
        level_group.columnconfigure(1, weight=1)
        self.level_tracking_button = RoundedButton(
            level_group, text="Seviye Kapalı", command=self._toggle_level_tracking,
            background=THEME["panel"], accent="#858585", hover="#9A9A9A",
            font=("Segoe UI", 8, "bold"), padx=3, height=23,
        )
        self.level_tracking_button.grid(row=0, column=0, sticky="w", padx=(2, 3), pady=4)
        tk.Label(
            level_group, text="seçilen coin'in giriş ve hedef seviyelerini izler",
            bg=THEME["panel"], fg=THEME["muted"], font=("Segoe UI", 8),
            justify="left", anchor="w", wraplength=94,
        ).grid(row=0, column=1, sticky="ew", padx=(0, 3))
        self.brightness_group = tk.Frame(self.alarm_controls_frame, bg=THEME["panel"])
        self.brightness_group.grid(row=0, column=4, sticky="nsew", padx=1)
        self.brightness_group.columnconfigure(1, weight=1)
        self.brightness_scale = tk.Scale(
            self.brightness_group, from_=0, to=100, resolution=1, orient="horizontal",
            variable=self.screen_brightness_var, command=self._apply_screen_brightness,
            showvalue=True, length=74, width=9, sliderlength=12, highlightthickness=0, bd=0,
            bg=THEME["panel"], fg=THEME["text"], troughcolor=THEME["panel_alt"],
            activebackground=THEME["accent_active"], font=("Segoe UI", 7),
        )
        self.brightness_scale.grid(row=0, column=0, sticky="w", padx=(2, 3), pady=2)
        self.brightness_scale.bind("<ButtonRelease-1>", self._save_brightness_setting)
        self.brightness_scale.bind("<KeyRelease>", self._save_brightness_setting)
        tk.Label(
            self.brightness_group, text="ekranı aydınlatır veya koyulaştırır",
            bg=THEME["panel"], fg=THEME["muted"], font=("Segoe UI", 8),
            justify="left", anchor="w", wraplength=80,
        ).grid(row=0, column=1, sticky="ew", padx=(0, 3))
        # Brightness stays next to sound-volume control, when the available width allows.
        self.brightness_group.grid_configure(column=2)
        test_group.grid_configure(column=3)
        level_group.grid_configure(column=4)
        self._refresh_alarm_controls()

        # Keep market identity and universe size in distinct, same-row fields.
        universe_box = ttk.Frame(outer)
        universe_box.grid(row=3, column=0, sticky="ew", pady=(0, 3))
        universe_box.columnconfigure(0, weight=1, uniform="universe-fields")
        universe_box.columnconfigure(1, weight=1, uniform="universe-fields")
        market_field = tk.Frame(
            universe_box, bg=THEME["panel"], highlightthickness=1,
            highlightbackground=THEME["border"], padx=7, pady=3,
        )
        market_field.grid(row=0, column=0, sticky="ew", padx=(0, 3))
        market_field.columnconfigure(1, weight=1)
        self.universe_market_caption = tk.Label(
            market_field, text="Piyasa", bg=THEME["panel"], fg=THEME["muted"],
            font=("Segoe UI", 10, "bold"), anchor="w",
        )
        self.universe_market_caption.grid(row=0, column=0, sticky="w", padx=(0, 8))
        self.universe_market_value = tk.Label(
            market_field, textvariable=self.universe_market_var,
            bg=THEME["panel"], fg=THEME["text"], font=("Segoe UI", 10),
            anchor="w", justify="left",
        )
        self.universe_market_value.grid(row=0, column=1, sticky="ew")
        pairs_field = tk.Frame(
            universe_box, bg=THEME["panel"], highlightthickness=1,
            highlightbackground=THEME["border"], padx=7, pady=3,
        )
        pairs_field.grid(row=0, column=1, sticky="ew", padx=(3, 0))
        pairs_field.columnconfigure(1, weight=1)
        self.universe_pairs_caption = tk.Label(
            pairs_field, text="Parite Evreni", bg=THEME["panel"], fg=THEME["muted"],
            font=("Segoe UI", 10, "bold"), anchor="w",
        )
        self.universe_pairs_caption.grid(row=0, column=0, sticky="w", padx=(0, 8))
        self.universe_pairs_value = tk.Label(
            pairs_field, textvariable=self.universe_pairs_var,
            bg=THEME["panel"], fg=THEME["text"], font=("Segoe UI", 10),
            anchor="w", justify="left",
        )
        self.universe_pairs_value.grid(row=0, column=1, sticky="ew")
        tk.Label(
            universe_box, textvariable=self.universe_compact_var,
            bg=THEME["background"], fg=THEME["muted"], font=("Segoe UI", 9),
            anchor="w", justify="left", wraplength=1250,
        ).grid(row=1, column=0, columnspan=2, sticky="ew", pady=(2, 0))
        self.btc_context_label = tk.Label(
            universe_box, textvariable=self.btc_context_var,
            bg=THEME["panel"], fg=THEME["text"], font=("Segoe UI", 9, "bold"),
            anchor="w", justify="left", wraplength=1250, padx=7, pady=3,
        )
        self.btc_context_label.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(3, 0))

        # Removing the helper sentence gives the candidate table more height.
        main = ttk.Frame(outer)
        main.grid(row=4, column=0, sticky="nsew", pady=(0, 4))
        main.columnconfigure(0, weight=1)
        main.rowconfigure(0, weight=5)
        main.rowconfigure(1, weight=0)
        main.rowconfigure(2, weight=4)

        candidate_box = self.candidate_box = ttk.LabelFrame(main, text="Öncelikli adaylar", padding=(6, 3))
        candidate_box.grid(row=0, column=0, sticky="nsew", pady=(0, 4))
        candidate_box.rowconfigure(0, weight=1)
        candidate_box.columnconfigure(0, weight=1)
        columns = ("symbol", "decision", "score", "phase", "price", "freshness", "timeframe")
        self.candidate_tree = ttk.Treeview(
            candidate_box, columns=columns, show="headings", height=5, style="Panel.Treeview"
        )
        headings = {
            "symbol": ("Coin / parite", 120),
            "decision": ("Nihai karar", 188),
            "score": ("Puan", 58),
            "phase": ("A/B/C", 106),
            "price": ("Fiyat (USDT)", 120),
            "freshness": ("Veri", 92),
            "timeframe": ("Zaman", 78),
        }
        for key, (label, width) in headings.items():
            self.candidate_tree.heading(key, text=label)
            self.candidate_tree.column(key, width=width, minwidth=min(width, 54), stretch=True)
        ybar = ttk.Scrollbar(candidate_box, orient="vertical", command=self.candidate_tree.yview,
                             style="Slim.Vertical.TScrollbar")
        self.candidate_tree.configure(yscrollcommand=ybar.set)
        self.candidate_tree.grid(row=0, column=0, sticky="nsew")
        ybar.grid(row=0, column=1, sticky="ns")
        self.candidate_tree.bind("<<TreeviewSelect>>", self._show_selected_candidate)
        self.candidate_tree.tag_configure("A", foreground=PHASE_COLORS["A"])
        self.candidate_tree.tag_configure("B", foreground=PHASE_COLORS["B"])
        self.candidate_tree.tag_configure("C", foreground=PHASE_COLORS["C"])
        self.candidate_tree.tag_configure("stale", foreground=STATUS_COLORS["blue"])
        self.candidate_tree.tag_configure("decision", foreground=THEME["text"])
        self.candidate_tree.tag_configure("empty", foreground=THEME["muted"])

        detail_frame = self.detail_frame = ttk.LabelFrame(main, text="Seçilen adayın özeti", padding=(7, 4))
        detail_frame.grid(row=2, column=0, sticky="nsew", pady=(0, 4))
        detail_frame.rowconfigure(1, weight=1)
        detail_frame.columnconfigure(0, weight=1)
        ttk.Label(detail_frame, textvariable=self.selected_candidate_var,
                  font=("Segoe UI", 10, "bold"), style="Panel.TLabel",
                  wraplength=900, justify="left").grid(
                      row=0, column=0, sticky="ew", pady=(0, 3))
        detail_text_frame = ttk.Frame(detail_frame)
        detail_text_frame.grid(row=1, column=0, sticky="nsew")
        detail_text_frame.rowconfigure(0, weight=1)
        detail_text_frame.columnconfigure(0, weight=1)
        self.detail = tk.Text(
            detail_text_frame, height=8, wrap="word", font=("Segoe UI", 10), state="disabled",
            background=THEME["field"], foreground=THEME["text"],
            insertbackground=THEME["text"], selectbackground=THEME["selection"],
            selectforeground="#FFFFFF", relief="flat", borderwidth=0,
            highlightthickness=1, highlightbackground=THEME["border"], highlightcolor=THEME["border"],
        )
        detail_scroll = ttk.Scrollbar(detail_text_frame, orient="vertical", command=self.detail.yview,
                                       style="Slim.Vertical.TScrollbar")
        self.detail.configure(yscrollcommand=detail_scroll.set)
        self.detail.grid(row=0, column=0, sticky="nsew")
        detail_scroll.grid(row=0, column=1, sticky="ns")
        self.detail.tag_configure("scenario", foreground=PHASE_COLORS["C"])
        self.detail.tag_configure("entry", foreground=THEME["text"])
        self.detail.tag_configure("breakout", foreground=STATUS_COLORS["yellow"])
        self.detail.tag_configure("stop", foreground=STATUS_COLORS["red"])
        self.detail.tag_configure("targets", foreground=STATUS_COLORS["lilac"])
        self.detail.tag_configure("fresh_current", foreground="#FFFFFF", background=STATUS_COLORS["green"])
        self.detail.tag_configure("fresh_stale", foreground="#FFFFFF", background=STATUS_COLORS["blue"],
                                  font=("Segoe UI", 12, "bold"))

        # Sayısal risk senaryosu ayrıdır; metin ayrıntısındaki uyarı ve koşulları tekrarlar.
        self.risk_box = ttk.LabelFrame(main, text="Giriş kontrolü — yalnızca Binance verisi", padding=(7, 5))
        risk_box = self.risk_box
        risk_box.grid(row=1, column=0, sticky="ew", pady=(0, 4))
        risk_box.columnconfigure(0, weight=1)
        for index, key in enumerate(("scenario", "breakout")):
            widget = tk.Text(
                risk_box, width=42, height=1, wrap="none", font=("Segoe UI", 10),
                state="disabled", background=THEME["panel"], foreground=THEME["text"],
                relief="flat", borderwidth=0, highlightthickness=0, padx=0, pady=0,
            )
            widget.tag_configure("scenario_title", foreground=PHASE_COLORS["C"])
            widget.tag_configure("entry_title", foreground=THEME["text"])
            widget.tag_configure("breakout_title", foreground=STATUS_COLORS["yellow"])
            widget.tag_configure("stop_title", foreground=STATUS_COLORS["red"])
            widget.tag_configure("targets_title", foreground=STATUS_COLORS["lilac"])
            widget.grid(row=index, column=0, sticky="ew", pady=(0, 1))
            self.risk_row_widgets[key] = widget

        # Günlükler arayüzde gösterilmez; tanılama dosyaya yazılır.
        self._sync_risk_rows()
        self._set_text(self.detail, "Coin seçin. A/B/C birer araştırma aşamasıdır; emir değildir.")
        self._append_log(
            "Tek motorlu panel hazır: referans yerleşimi etkin. Yalnızca Binance analiz motoru çalışır."
        )

    def _sync_risk_rows(self, *_args: Any) -> None:
        """Refresh two compact entry-control rows using the live plan values."""
        values = self.risk_vars
        rows = {
            "scenario": (
                f"senaryo / zaman dilimi: {values['scenario'].get()}   ·   "
                f"olası giriş bölgesi: {values['entry'].get()}"
            ),
            "breakout": (
                f"kırılım seviyesi: {values['breakout'].get()}   ·   "
                f"zarar durdurma: {values['stop'].get()}"
            ),
        }
        segments = {
            "scenario": [
                ("senaryo / zaman dilimi: ", "scenario_title"),
                (values["scenario"].get(), None),
                ("   ·   ", None),
                ("olası giriş bölgesi: ", "entry_title"),
                (values["entry"].get(), None),
            ],
            "breakout": [
                ("kırılım seviyesi: ", "breakout_title"),
                (values["breakout"].get(), None),
                ("   ·   ", None),
                ("zarar durdurma: ", "stop_title"),
                (values["stop"].get(), None),
            ],
        }
        for key, value in rows.items():
            self.risk_row_vars[key].set(value)
            widget = self.risk_row_widgets.get(key)
            if widget is None:
                continue
            widget.configure(state="normal")
            widget.delete("1.0", "end")
            for content, tag in segments[key]:
                if tag:
                    widget.insert("end", content, tag)
                else:
                    widget.insert("end", content)
            widget.configure(state="disabled")

    @staticmethod
    def _set_text(widget: tk.Text, value: str) -> None:
        """Replace detail text without stealing the reader's current scroll position."""
        old_value = widget.get("1.0", "end-1c")
        if old_value == value:
            return
        try:
            old_yview = widget.yview()
        except tk.TclError:
            old_yview = (0.0, 1.0)
        was_at_bottom = old_yview[0] > 0.001 and old_yview[1] >= 0.995
        widget.configure(state="normal")
        widget.delete("1.0", "end")
        widget.insert("1.0", value)
        if was_at_bottom:
            widget.yview_moveto(1.0)
        else:
            widget.yview_moveto(old_yview[0])
        widget.configure(state="disabled")

    def _append_log(self, line: str) -> None:
        """Persist diagnostics and worker stdout/stderr without adding a visible log panel."""
        self._panel_logger.info("%s", str(line))

    def _engine_command(self) -> list[str]:
        if getattr(sys, "frozen", False):
            worker = ROOT / "binance_erken_firsat_radari.exe"
            if not worker.is_file():
                raise FileNotFoundError("Binance motoru dosyası pakette bulunamadı.")
            return [str(worker)]
        worker = ROOT / "binance_erken_firsat_radari.py"
        return [_python_console_exe(), str(worker)]

    def _start_engine(self) -> None:
        if self.process is not None and self.process.poll() is None:
            self._append_log("Binance motoru zaten çalışıyor.")
            return
        try:
            STOP_PATH.unlink(missing_ok=True)
            REFRESH_PATH.unlink(missing_ok=True)
            atomic_json(STATE_PATH, {
                "radar": "Tek Motor — Binance Spot",
                "status": "BAŞLATILIYOR",
                "generated_at_utc": utc_now(),
                "candidates": [],
            })
            command = self._engine_command() + [
                "--stop-file", str(STOP_PATH), "--single-engine"
            ]
            env = os.environ.copy()
            env["PYTHONUTF8"] = "1"
            env["PYTHONIOENCODING"] = "utf-8"
            self.process = subprocess.Popen(
                command,
                cwd=str(ROOT),
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                bufsize=1,
                env=env,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0,
            )
            self._start_clock = _now_clock()
            self.start_clock_var.set(f"Başlatma saati: {self._start_clock}")
            self.engine_status.set("Başlatılıyor")
            self.start_button.configure(state="disabled")
            self.stop_button.configure(state="normal")
            self._active_opportunities.clear()
            self._inactive_since.clear()
            self._last_alert_reason.clear()
            self._last_strong_keys.clear()
            thread = threading.Thread(target=self._read_process_output, args=(self.process,), daemon=True)
            thread.start()
            self._append_log("Binance tek analiz motoru başlatıldı.")
        except Exception as exc:
            self.engine_status.set("Başlatma hatası")
            self._append_log(f"Motor başlatılamadı: {exc}")
            messagebox.showerror("Motor başlatılamadı", str(exc), parent=self.root)
            self.start_button.configure(state="normal")
            self.stop_button.configure(state="disabled")

    def _read_process_output(self, process: subprocess.Popen[str]) -> None:
        stream = process.stdout
        if stream is None:
            return
        try:
            for line in stream:
                self.output_queue.put(line.rstrip())
        except (OSError, ValueError) as exc:
            self.output_queue.put(f"Motor çıktısı okunamadı: {exc}")

    def _stop_engine(self) -> None:
        if self.process is None or self.process.poll() is not None:
            self.engine_status.set("Durduruldu")
            self._append_log("Çalışan Binance motoru yok.")
            return
        try:
            STOP_PATH.write_text("stop\n", encoding="utf-8")
            self.engine_status.set("Durduruluyor")
            self._append_log("Binance motoruna kontrollü durdurma istendi.")
            self.stop_button.configure(state="disabled")
        except OSError as exc:
            self._append_log(f"Durdurma isteği yazılamadı: {exc}")

    def _update_local_list(self) -> None:
        if str(self.update_list_button["state"]) == "disabled":
            return
        self.update_list_button.configure(state="disabled")
        self._append_log("BtcTurk USDT sembol listesi güncelleniyor; bu işlem analiz motorundan ayrıdır.")

        def task() -> None:
            try:
                result = update_local_btcturk_list()
                self.event_queue.put(("list_ok", result))
            except Exception as exc:
                self.event_queue.put(("list_error", str(exc)))

        threading.Thread(target=task, daemon=True, name="local-symbol-list-update").start()

    def _local_list_summary(self) -> str:
        try:
            _symbols, meta = load_local_btcturk_symbols()
            age_hours = float(meta.get("age_seconds", 0)) / 3600.0
            warning = f" | UYARI: {meta['warning']}" if meta.get("warning") else ""
            return (
                f"Yerel BtcTurk sembol listesi: {meta['count']} parite | "
                f"son güncelleme: {meta['generated_at_utc']} | yaş: {age_hours:.1f} saat"
                f"{warning}"
            )
        except Exception as exc:
            return f"Yerel BtcTurk listesi hazır değil: {exc}"

    @staticmethod
    def _state_age(state: dict[str, Any]) -> float | None:
        value = state.get("generated_at_utc")
        try:
            stamp = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
            if stamp.tzinfo is None:
                stamp = stamp.replace(tzinfo=timezone.utc)
            return max(0.0, (datetime.now(timezone.utc) - stamp.astimezone(timezone.utc)).total_seconds())
        except (TypeError, ValueError, OverflowError):
            return None

    def _state_is_live(self) -> bool:
        if self.process is None or self.process.poll() is not None:
            return False
        age = self._state_age(self._state)
        if (
            self._state.get("status") != "CANLI AKIŞ GÜNCEL"
            or age is None or age > 90
            or self._state.get("settings_changed_since_load") is True
        ):
            return False
        total = int(self._state.get("websocket_total_shards") or 0)
        connected = int(self._state.get("websocket_connected_shards") or 0)
        return total > 0 and total == connected

    def _candidate_is_current(self, row: dict[str, Any] | None) -> bool:
        """Require the candidate row and shared engine state to both be current."""
        return (
            isinstance(row, dict)
            and row.get("data_freshness") == "CANLI AKIŞ GÜNCEL"
            and self._state_is_live()
        )

    def _current_rows(self) -> list[dict[str, Any]]:
        candidates = self._state.get("candidates")
        if not isinstance(candidates, list):
            return []
        rows = []
        for row in candidates:
            if not isinstance(row, dict):
                continue
            if (
                row.get("phase") not in ("A", "B", "C")
                and row.get("last_known_phase") not in ("A", "B", "C")
                and _final_decision_text(row) == "KARAR BEKLENİYOR"
            ):
                continue
            rows.append(row)
        # The motor ranks candidates by decision, score, phase, higher-timeframe context,
        # and evidence. Preserve that exact order for the panel, alert lifecycle, and report.
        return rows

    def _strong_rows(self) -> dict[tuple[str, str], tuple[dict[str, Any], str]]:
        if not self._state_is_live() or self._state.get("strong_alerts_enabled") is not True:
            return {}
        output: dict[tuple[str, str], tuple[dict[str, Any], str]] = {}
        for row in self._current_rows():
            if row.get("data_freshness") != "CANLI AKIŞ GÜNCEL":
                continue
            if row.get("strong_alarm_eligible") is not True:
                continue
            reason = _strong_opportunity_reason(row)
            if not reason:
                continue
            symbol = str(row.get("symbol") or "").strip().upper()
            timeframe = str(row.get("phase_timeframe") or "").strip()
            if symbol and timeframe:
                output[(symbol, timeframe)] = (row, reason)
        return output

    def _refresh_alert_lifecycle(self) -> None:
        now = time.monotonic()
        current = self._strong_rows()
        rows_by_symbol = {
            str(row.get("symbol") or "").strip().upper(): row
            for row in self._current_rows() if str(row.get("symbol") or "").strip()
        }
        state_is_live = self._state_is_live()
        alerts_enabled = self._state.get("strong_alerts_enabled") is True
        btc_gate = self._state.get("btc_strong_alert_gate")
        btc_context_current_and_eligible = (
            isinstance(btc_gate, dict)
            and btc_gate.get("fresh") is True
            and btc_gate.get("complete") is True
            and btc_gate.get("eligible") is True
        )
        global_permission_revoked = (
            state_is_live
            and self._state.get("strong_alerts_enabled") is False
            and btc_context_current_and_eligible
        )
        btc_confirmed_risk_closes_alert = (
            state_is_live
            and not alerts_enabled
            and isinstance(btc_gate, dict)
            and btc_gate.get("fresh") is True
            and btc_gate.get("complete") is True
            and (
                bool(btc_gate.get("critical_level_loss_timeframes"))
                or btc_gate.get("extreme_volatility") is True
            )
        )
        btc_gate_reasons = (
            [item.strip() for item in btc_gate.get("reasons", [])
             if isinstance(item, str) and item.strip()]
            if isinstance(btc_gate, dict) and isinstance(btc_gate.get("reasons"), list)
            else []
        )
        active_keys = set(self._active_opportunities)
        new_alerts = []
        invalidated_messages: list[str] = []
        for key, (row, reason) in current.items():
            self._inactive_since.pop(key, None)
            self._inactive_elapsed.pop(key, None)
            if key not in active_keys:
                new_alerts.append((key, row, reason))
                self._last_alert_reason[key] = reason
            active_keys.add(key)

        for key in list(active_keys):
            if key in current:
                continue
            row = rows_by_symbol.get(key[0])
            explicitly_invalidated = (
                state_is_live and isinstance(row, dict)
                and row.get("data_freshness") == "CANLI AKIŞ GÜNCEL"
                and row.get("strong_alarm_eligible") is True
                and str(row.get("phase_timeframe") or "").strip() == key[1]
                and row.get("final_decision") == "FIRSAT GEÇERSİZ"
            )
            if explicitly_invalidated:
                reason = row.get("decision_reason")
                reason_text = (
                    " ".join(reason.split())
                    if isinstance(reason, str) and reason.strip()
                    else "Teknik senaryo güncel verilerle geçersiz sayıldı."
                )
                message = f"FIRSAT GEÇERSİZ: {key[0]} {key[1]} — {reason_text}"
                active_keys.discard(key)
                self._inactive_since.pop(key, None)
                self._inactive_elapsed.pop(key, None)
                self._last_alert_reason.pop(key, None)
                self._append_log(message)
                invalidated_messages.append(message)
                continue
            if btc_confirmed_risk_closes_alert:
                reason_text = "; ".join(btc_gate_reasons[:2]) or (
                    "BTC kritik destek/kanal kaybı veya aşırı oynaklık eşiği doğrulandı."
                )
                message = (
                    f"GÜÇLÜ FIRSAT ALARMI KAPANDI: BTC piyasa risk kapısı — "
                    f"{key[0]} {key[1]} — {reason_text}"
                )
                active_keys.discard(key)
                self._inactive_since.pop(key, None)
                self._inactive_elapsed.pop(key, None)
                self._last_alert_reason.pop(key, None)
                self._append_log(message)
                invalidated_messages.append(message)
                continue
            row_permission_revoked = (
                state_is_live
                and btc_context_current_and_eligible
                and isinstance(row, dict)
                and row.get("data_freshness") == "CANLI AKIŞ GÜNCEL"
                and row.get("btc_market_context_freshness") == "CANLI AKIŞ GÜNCEL"
                and str(row.get("phase_timeframe") or "").strip() == key[1]
                and row.get("strong_alarm_eligible") is False
            )
            if global_permission_revoked or row_permission_revoked:
                if global_permission_revoked:
                    raw_warning = self._state.get("alert_filter_warning")
                    reason_text = (
                        " ".join(raw_warning.split())
                        if isinstance(raw_warning, str) and raw_warning.strip()
                        else "Genel parite/ayar uygunluk izni kaldırıldı."
                    )
                    permission_label = "genel alarm izni kaldırıldı"
                else:
                    raw_warning = row.get("strong_alarm_block_reason")
                    reason_text = (
                        " ".join(raw_warning.split())
                        if isinstance(raw_warning, str) and raw_warning.strip()
                        else "Parite güçlü alarm uygunluğunu kaybetti."
                    )
                    permission_label = "parite alarm uygunluğu kaldırıldı"
                message = (
                    f"GÜÇLÜ FIRSAT ALARMI KAPANDI: {permission_label} — "
                    f"{key[0]} {key[1]} — {reason_text}"
                )
                active_keys.discard(key)
                self._inactive_since.pop(key, None)
                self._inactive_elapsed.pop(key, None)
                self._last_alert_reason.pop(key, None)
                self._append_log(message)
                invalidated_messages.append(message)
                continue
            can_confirm_inactive = (
                state_is_live and alerts_enabled and isinstance(row, dict)
                and row.get("data_freshness") == "CANLI AKIŞ GÜNCEL"
                and row.get("strong_alarm_eligible") is True
            )
            if not can_confirm_inactive:
                # Accumulate only time during which fresh data actually confirms absence.
                since = self._inactive_since.pop(key, None)
                if since is not None:
                    self._inactive_elapsed[key] = self._inactive_elapsed.get(key, 0.0) + max(0.0, now - since)
                continue
            since = self._inactive_since.setdefault(key, now)
            fresh_absence_seconds = self._inactive_elapsed.get(key, 0.0) + max(0.0, now - since)
            if fresh_absence_seconds >= 300.0:
                active_keys.discard(key)
                self._inactive_since.pop(key, None)
                self._inactive_elapsed.pop(key, None)
                self._last_alert_reason.pop(key, None)
                self._append_log(
                    f"Fırsat sona erdi: {key[0]} {key[1]} — koşul 300 saniyedir güncel verilerle doğrulanmıyor."
                )

        self._active_opportunities = active_keys
        self._last_strong_keys = set(current)
        for key, row, reason in new_alerts:
            price = row.get("latest_price")
            price_text = f"{float(price):.10g}" if isinstance(price, (int, float)) else "belirsiz"
            message = (
                f"GÜÇLÜ FIRSAT | motor=Binance Spot | veri=CANLI AKIŞ GÜNCEL | "
                f"parite={key[0]} | fiyat={price_text} USDT | {reason}"
            )
            self.alert_banner.set(message)
            self._append_log(message)
            self._play_alert_tone("strong")
        if not current and not new_alerts:
            if invalidated_messages:
                self.alert_banner.set(invalidated_messages[-1])
            elif self._state.get("strong_alerts_enabled", True) is False:
                disabled_reasons: list[str] = []
                btc_gate = self._state.get("btc_strong_alert_gate")
                if isinstance(btc_gate, dict) and btc_gate.get("eligible") is False:
                    raw_reasons = btc_gate.get("reasons")
                    if isinstance(raw_reasons, list):
                        disabled_reasons.extend(
                            item.strip() for item in raw_reasons
                            if isinstance(item, str) and item.strip()
                        )
                filter_warning = self._state.get("alert_filter_warning")
                if isinstance(filter_warning, str) and filter_warning.strip():
                    cleaned_warning = " ".join(filter_warning.split())
                    if cleaned_warning not in disabled_reasons:
                        disabled_reasons.append(cleaned_warning)
                if disabled_reasons:
                    self.alert_banner.set(
                        "Güçlü fırsat alarmı kapalı: " + " | ".join(disabled_reasons[:2])
                    )
                else:
                    self.alert_banner.set(
                        "Güçlü fırsat alarmı kapalı: filtre ve BTC uygunluk gerekçesi mevcut değil."
                    )
            elif self._state_is_live():
                self.alert_banner.set("Canlı veri güncel. Şu anda güçlü fırsat koşullarını karşılayan aday yok.")
            elif self.process is not None and self.process.poll() is None:
                self.alert_banner.set("Veri güncelliği/bağlantı doğrulanamadı. Güçlü fırsat alarmı kapalı.")
            else:
                self.alert_banner.set("Alarm yalnızca güncel verilerle doğrulanan güçlü fırsatlarda etkinleşir.")

    def _refresh_candidates(self) -> None:
        rows = self._current_rows()
        engine_live = self._state_is_live()
        selected = self.candidate_tree.selection()
        selected_symbol = selected[0] if selected else None
        try:
            old_yview = self.candidate_tree.yview()
        except tk.TclError:
            old_yview = (0.0, 1.0)
        y_was_at_bottom = old_yview[0] > 0.001 and old_yview[1] >= 0.995
        self._rows_by_symbol = {}
        wanted: set[str] = set()
        for row in rows:
            symbol = str(row.get("symbol") or "").upper()
            if not symbol:
                continue
            wanted.add(symbol)
            self._rows_by_symbol[symbol] = row
            freshness = str(row.get("data_freshness") or "veri durumu bilinmiyor")
            candidate_is_live = engine_live and freshness == "CANLI AKIŞ GÜNCEL"
            is_current_phase = candidate_is_live and row.get("phase") in PHASE_COLORS
            phase = row.get("phase") if is_current_phase else (
                row.get("last_known_phase") or row.get("phase")
            )
            price = row.get("latest_price")
            price_text = (
                f"{float(price):.10g}"
                if candidate_is_live and isinstance(price, (int, float))
                and not isinstance(price, bool)
                and math.isfinite(float(price)) and float(price) > 0
                else "—"
            )
            display_row = row if candidate_is_live else {
                **row, "data_freshness": "CANLI VERİ ESKİ/EKSİK"
            }
            decision_text = _final_decision_text(display_row)
            score_text = _opportunity_score_text(display_row)
            if is_current_phase and phase in PHASE_COLORS:
                phase_text = {"A": "A · Hazırlık", "B": "B · İlk teyit", "C": "C · Devam"}[phase]
            elif phase in PHASE_COLORS:
                phase_text = f"Son {phase} · Eski"
            else:
                phase_text = "—"
            freshness_text = (
                "Güncel" if candidate_is_live else
                "Eski/eksik" if (
                    not engine_live
                    or freshness in {"CANLI VERİ ESKİ/EKSİK", "GÜNCEL DEĞİL"}
                ) else "Bilinmiyor"
            )
            values = (
                symbol, decision_text, score_text, phase_text, price_text,
                freshness_text, str(row.get("phase_timeframe") or "—"),
            )
            tag = phase if is_current_phase and phase in PHASE_COLORS else (
                "stale" if not candidate_is_live else "decision"
            )
            if self.candidate_tree.exists(symbol):
                self.candidate_tree.item(symbol, values=values, tags=(tag,))
            else:
                self.candidate_tree.insert("", "end", iid=symbol, values=values, tags=(tag,))
        for item in self.candidate_tree.get_children():
            if item not in wanted and item != "__NO_CANDIDATES__":
                self.candidate_tree.delete(item)
        if not rows:
            if not self.candidate_tree.exists("__NO_CANDIDATES__"):
                self.candidate_tree.insert("", "end", iid="__NO_CANDIDATES__",
                    values=("Aday yok", "Karar bekleniyor", "—", "—", "—", "Tarama bekleniyor", "—"),
                    tags=("empty",))
        elif self.candidate_tree.exists("__NO_CANDIDATES__"):
            self.candidate_tree.delete("__NO_CANDIDATES__")
        if selected_symbol and selected_symbol in wanted:
            self.candidate_tree.selection_set(selected_symbol)
            # Refresh the detail/risk area without moving the user's viewport.
            self._show_selected_candidate()
        elif rows and not self.candidate_tree.selection():
            self.candidate_tree.selection_set(str(rows[0].get("symbol") or "").upper())
            self._show_selected_candidate()
        elif not rows:
            self.selected_candidate_var.set("Coin seçilmedi")
            self._set_text(self.detail, "Şu an aşama taşıyan aday yok. Tarama motoru çalışıyor olabilir; veri durumu yukarıda gösterilir.")
            self._update_risk_summary(None)
        try:
            self.candidate_tree.yview_moveto(1.0 if y_was_at_bottom else old_yview[0])
        except tk.TclError:
            pass
        self._update_price_level_tracking()

    def _update_risk_summary(self, row: dict[str, Any] | None) -> None:
        """Update the separate risk strip from the selected candidate's current plan."""
        empty_values = {
            "scenario": "—", "entry": "—", "breakout": "—", "stop": "—",
            "targets": "—", "risk": "—", "rr": "—", "status": "Plan yok",
        }
        if not isinstance(row, dict):
            for key, value in empty_values.items():
                self.risk_vars[key].set(value)
            self.risk_note_var.set("Coin seçin. Sayısal plan yalnızca güncel veri ve yeterli teknik kanıtla üretilir.")
            return

        if not self._candidate_is_current(row):
            for key, value in empty_values.items():
                self.risk_vars[key].set(value)
            self.risk_vars["scenario"].set("güncel değil")
            self.risk_vars["status"].set("Veri bekleniyor")
            if row.get("data_freshness") == "CANLI AKIŞ GÜNCEL":
                self.risk_note_var.set(
                    "Genel motor/veri durumu güncel olarak doğrulanamadı; eski giriş, "
                    "zarar durdurma ve hedef seviyeleri gösterilmiyor."
                )
            else:
                self.risk_note_var.set(
                    "Canlı veri eski/eksik: mum akışı doğrulanmadı; eski giriş, "
                    "zarar durdurma ve hedef seviyeleri gösterilmiyor."
                )
            return

        plan = row.get("risk_plan") if isinstance(row.get("risk_plan"), dict) else {}
        latest_phase = row.get("phase")
        phase = latest_phase or "Aşama yok"
        timeframe = plan.get("timeframe") or row.get("phase_timeframe") or "—"

        def number(value: Any) -> str:
            if isinstance(value, (int, float)):
                try:
                    return f"{float(value):.8g}"
                except (TypeError, ValueError, OverflowError):
                    return "—"
            return "—"

        entry_low, entry_high = plan.get("entry_zone_low"), plan.get("entry_zone_high")
        if entry_low is not None and entry_high is not None:
            entry = f"{number(entry_low)} – {number(entry_high)} USDT"
        else:
            entry = "—"
        targets = plan.get("targets") if isinstance(plan.get("targets"), list) else []
        target_parts = []
        rewards = []
        for index, target in enumerate(targets[:3], start=1):
            if not isinstance(target, dict):
                continue
            target_name = str(target.get("name") or f"Hedef {index}")
            target_parts.append(f"{target_name}: {number(target.get('price'))}")
            reward = target.get("risk_reward", target.get("risk_multiple"))
            if isinstance(reward, (int, float)):
                rewards.append(f"{number(reward)}R")
        self.risk_vars["scenario"].set(f"{phase} / {timeframe}")
        self.risk_vars["entry"].set(entry)
        self.risk_vars["breakout"].set(number(plan.get("breakout_level")) + (" USDT" if plan.get("breakout_level") is not None else ""))
        self.risk_vars["stop"].set(number(plan.get("stop_loss")) + (" USDT" if plan.get("stop_loss") is not None else ""))
        self.risk_vars["targets"].set(" | ".join(target_parts) if target_parts else "—")
        risk_pct = plan.get("risk_pct")
        self.risk_vars["risk"].set(f"%{number(risk_pct)}" if risk_pct is not None else "—")
        self.risk_vars["rr"].set(" / ".join(rewards) if rewards else "—")
        self.risk_vars["status"].set(str(plan.get("status") or "Plan yok"))
        note = str(plan.get("reason") or plan.get("target_basis") or plan.get("note") or
                   "Plan üretilemedi; yeterli güncel teknik veri bulunmuyor.")
        costs_note = str(plan.get("costs_note") or "")
        if costs_note:
            note += " " + costs_note
        self.risk_note_var.set(note)

    def _show_selected_candidate(self, _event: Any = None) -> None:
        selection = self.candidate_tree.selection()
        if not selection:
            return
        if (
            self.level_tracking_enabled_var.get()
            and self._tracked_symbol
            and selection[0] != self._tracked_symbol
        ):
            self._stop_level_tracking(
                f"Aday seçimi {selection[0]} olarak değişti; önceki coin'in seviye takibi kapatıldı."
            )
        row = self._rows_by_symbol.get(selection[0])
        if row is None:
            return
        candidate_is_live = self._candidate_is_current(row)
        display_row = dict(row)
        if not candidate_is_live:
            display_row["data_freshness"] = "CANLI VERİ ESKİ/EKSİK"
        visible_phase = row.get("phase") if candidate_is_live else None
        last_phase = row.get("last_known_phase") or row.get("phase")
        phase_label = (visible_phase if visible_phase in PHASE_COLORS else
                       f"Son {last_phase} — güncel değil" if last_phase in PHASE_COLORS else "Aşama yok")
        decision_text = _final_decision_text(display_row)
        score_text = _opportunity_score_text(display_row)
        self.selected_candidate_var.set(
            f"{row.get('symbol', '—')} | {decision_text} | Puan {score_text}/100"
            f" | {phase_label} | {row.get('phase_timeframe') or '—'}"
        )
        self._update_risk_summary(row)
        findings = row.get("findings") if isinstance(row.get("findings"), list) else []
        missing = row.get("missing_checks") if isinstance(row.get("missing_checks"), list) else []
        tf_assessments = row.get("timeframes") if isinstance(row.get("timeframes"), dict) else {}
        freshness = "CANLI AKIŞ GÜNCEL" if candidate_is_live else "CANLI VERİ ESKİ/EKSİK"
        freshness_display = (
            "canlı akış güncel" if candidate_is_live else "canlı veri eski/eksik"
        )

        def clipped(value: Any, limit: int = 78) -> str:
            text_value = " ".join(str(value).split())
            return text_value if len(text_value) <= limit else text_value[:limit - 1].rstrip() + "…"

        phase_text = (
            visible_phase if visible_phase in PHASE_COLORS else
            f"Son bilinen aşama: {last_phase} — güncel değil"
            if last_phase in PHASE_COLORS else "Güncel aşama yok"
        )
        lines = [
            f"Nihai karar: {decision_text} | Fırsat puanı: {score_text}/100",
            f"Aşama: {phase_text} | zaman dilimi: {row.get('phase_timeframe') or '—'}",
            f"Veri: {freshness_display} | fiyat: {row.get('latest_price', '—') if candidate_is_live else '—'} USDT | "
            f"Keşif yolu: {_discovery_path(row) if candidate_is_live else 'son kayıt — güncellik doğrulanamadı'}",
        ]
        decision_reason = row.get("decision_reason")
        if freshness != "CANLI AKIŞ GÜNCEL":
            decision_reason = "Canlı veri eski/eksik; güncel karar bekleniyor."
        if not isinstance(decision_reason, str) or not decision_reason.strip():
            gate_reasons = row.get("strong_opportunity_gate_reasons")
            decision_reason = next(
                (item for item in gate_reasons if isinstance(item, str) and item.strip()),
                "Karar gerekçesi motor kaydında bulunmuyor.",
            ) if isinstance(gate_reasons, list) else "Karar gerekçesi motor kaydında bulunmuyor."
        lines.insert(1, "Karar gerekçesi: " + clipped(decision_reason, 100))

        # Prefer the BTC-relative-strength summary and omit raw EMA/MACD/RSI/ADX/ATR metrics.
        finding_summary: list[str] = []
        relative_strength = next(
            (
                str(item) for item in findings
                if "btc" in str(item).lower() and "göreceli güç pozitif" in str(item).lower()
            ),
            None,
        )
        if relative_strength:
            finding_summary.append(clipped(relative_strength, 96))
        key_markers = ("geri test", "kırılım seviyesi sonraki", "sonraki kapanmış mumda",
                       "yükselen dip", "yönlü fiyat yapısı", "olağan dışı hacim")
        for item in findings:
            item_text = str(item)
            if item_text == relative_strength:
                continue
            if not any(marker in item_text.lower() for marker in key_markers):
                continue
            if item_text in finding_summary:
                continue
            finding_summary.append(clipped(item_text, 74))
            if len(finding_summary) >= 3:
                break
        if not finding_summary:
            finding_summary = [clipped(item, 74) for item in findings[:2]]
        findings_line = (
            "Bulgular: " + ("; ".join(finding_summary) if finding_summary else "Kayıtlı bulgu yok.")
        )
        correlation_summary = _btc_correlation_summary(row, current=candidate_is_live)
        findings_line += " | BTC korelasyonu: " + correlation_summary
        conflict_note = row.get("btc_context_conflict_note")
        if candidate_is_live and isinstance(conflict_note, str) and conflict_note.strip():
            findings_line += " | BTC/coin çelişkisi: " + clipped(conflict_note, 105)
        group_summary = row.get("group_leadership_summary") or row.get("group_leadership_basis")
        if candidate_is_live and isinstance(group_summary, str) and group_summary.strip():
            findings_line += " | Grup: " + clipped(group_summary, 84)
        lines.append(findings_line)

        missing_summary: list[str] = []
        # Leave one concise slot for the reason the strong-opportunity gate is still closed.
        for item in missing[:2]:
            missing_summary.append(clipped(item, 66))
        if candidate_is_live and decision_text != "GÜÇLÜ FIRSAT":
            gate_reasons = row.get("strong_opportunity_gate_reasons")
            if isinstance(gate_reasons, list):
                for item in gate_reasons:
                    if not isinstance(item, str) or not item.strip():
                        continue
                    if any(item.casefold() in existing.casefold() for existing in missing_summary):
                        continue
                    missing_summary.append(clipped(f"Güçlü fırsat kapısı: {item}", 66))
                    break
        if not missing_summary:
            for timeframe in ("5m", "15m", "30m", "1h", "4h", "1d", "1w", "1M"):
                assessment = tf_assessments.get(timeframe)
                if not isinstance(assessment, dict):
                    continue
                checks = assessment.get("missing_checks")
                if not isinstance(checks, list):
                    continue
                for item in checks:
                    missing_summary.append(clipped(f"{timeframe}: {item}", 66))
                    if len(missing_summary) >= 3:
                        break
                if len(missing_summary) >= 3:
                    break
        lines.append(
            "Eksik kontroller: " + ("; ".join(missing_summary) if missing_summary else "Kayıtlı eksik kontrol yok.")
        )

        lines.append("Koşullu giriş ve risk planı:")
        plan = (
            row.get("risk_plan")
            if candidate_is_live and isinstance(row.get("risk_plan"), dict)
            else None
        )

        def price_text(value: Any) -> str:
            if not isinstance(value, (int, float)):
                return "—"
            return f"{float(value):.8f}".rstrip("0").rstrip(".")

        def percent_text(value: Any) -> str:
            return f"{float(value):+.2f}%" if isinstance(value, (int, float)) else "—"

        if not isinstance(plan, dict):
            lines.append("Plan yok — güncel veri ve gerekli teknik doğrulamalar bekleniyor.")
            lines.append("Hedefler: —")
        else:
            status_text = clipped(plan.get("status") or "Plan yok", 88)
            entry_low, entry_high = plan.get("entry_zone_low"), plan.get("entry_zone_high")
            if entry_low is not None and entry_high is not None:
                entry_text = f"{price_text(entry_low)}–{price_text(entry_high)} USDT"
                reference = plan.get("entry_reference")
                if reference is not None:
                    entry_text += f" (referans {price_text(reference)})"
                lines.append(f"Durum: {status_text} | Giriş bölgesi: {entry_text}")
            else:
                lines.append(f"Durum: {status_text}")
                if plan.get("reason"):
                    lines.append("Plan notu: " + clipped(plan.get("reason"), 95))

            breakout = plan.get("breakout_level")
            stop = plan.get("stop_loss")
            risk_pct = plan.get("risk_pct")
            plan_levels = []
            if breakout is not None:
                plan_levels.append(f"Kırılım seviyesi: {price_text(breakout)} USDT")
            if stop is not None:
                plan_levels.append(f"Zarar durdurma: {price_text(stop)} USDT")
            if isinstance(risk_pct, (int, float)):
                plan_levels.append(f"Referans riski: %{float(risk_pct):.4f}")
            if plan_levels:
                lines.append(" | ".join(plan_levels))

            targets = plan.get("targets") if isinstance(plan.get("targets"), list) else []
            target_parts = []
            for index, target in enumerate(targets[:3], start=1):
                if not isinstance(target, dict):
                    continue
                name = str(target.get("name") or f"Hedef {index}")
                part = f"{name}: {price_text(target.get('price'))} USDT"
                if target.get("change_pct") is not None:
                    part += f" ({percent_text(target.get('change_pct'))})"
                reward = target.get("risk_reward", target.get("risk_multiple"))
                if isinstance(reward, (int, float)) and not isinstance(reward, bool):
                    part += f" · {float(reward):g}R"
                basis = target.get("basis")
                source_timeframes = target.get("source_timeframes")
                source_labels = [
                    str(item).strip() for item in source_timeframes
                    if isinstance(item, str) and item.strip()
                ] if isinstance(source_timeframes, list) else []
                if isinstance(basis, str) and basis.strip():
                    part += " · dayanak: " + clipped(basis, 54)
                    if source_labels:
                        part += " (" + ", ".join(source_labels[:4]) + ")"
                target_parts.append(part)

            target_display = " | ".join(target_parts) if target_parts else "—"
            net_rr = plan.get("net_risk_reward")
            net_rr_is_number = (
                isinstance(net_rr, (int, float))
                and not isinstance(net_rr, bool)
                and math.isfinite(float(net_rr))
            )
            if plan.get("costs_included") is True and net_rr_is_number:
                net_rr_label = (
                    " · Masraf sonrası net risk/getiri (ilk teknik hedef): "
                    f"{float(net_rr):.2f}"
                )
            elif plan.get("costs_included") is True:
                net_rr_label = " · Masraf sonrası net risk/getiri hesaplanamadı"
            else:
                net_rr_label = " · Masraf sonrası net risk/getiri doğrulanmadı"
            lines.append("Hedefler: " + target_display + net_rr_label)

            invalid_if = plan.get("invalid_if")
            if invalid_if:
                lines.append("Geçersizlik: " + clipped(invalid_if, 100))
            costs_note = plan.get("costs_note")
            if costs_note:
                lines.append("Maliyet notu: " + clipped(costs_note, 92))
        detail_text = "\n".join(lines)
        self._set_text(self.detail, detail_text)
        self._apply_detail_highlights(detail_text)

    def _apply_detail_highlights(self, value: str) -> None:
        """Color only key words; keep the body text and numeric values readable."""
        phrases = (
            ("senaryo / zaman dilimi:", "scenario"),
            ("Aşama:", "scenario"),
            ("zaman dilimi:", "scenario"),
            ("olası giriş bölgesi:", "entry"),
            ("Giriş bölgesi:", "entry"),
            ("Kırılım seviyesi:", "breakout"),
            ("Zarar durdurma:", "stop"),
            ("Hedef 1", "targets"),
            ("Hedef 2", "targets"),
            ("Hedef 3", "targets"),
            ("canlı akış güncel", "fresh_current"),
            ("canlı veri eski/eksik", "fresh_stale"),
            ("güncel değil", "fresh_stale"),
        )
        for _phrase, tag in phrases:
            self.detail.tag_remove(tag, "1.0", "end")
        for phrase, tag in phrases:
            offset = 0
            while True:
                index = value.find(phrase, offset)
                if index < 0:
                    break
                start = f"1.0 + {index} chars"
                end = f"1.0 + {index + len(phrase)} chars"
                self.detail.tag_add(tag, start, end)
                offset = index + len(phrase)

    def _refresh_state(self) -> None:
        state = load_json(STATE_PATH, {}) or {}
        if not isinstance(state, dict):
            state = {}
        self._state = state
        live = self._state_is_live()
        process_running = self.process is not None and self.process.poll() is None
        status = str(state.get("status") or "Durum verisi yok").strip()
        if not live and status == "CANLI AKIŞ GÜNCEL":
            status = "BAĞLANTI/VERİ UYARISI"
        if process_running and live:
            self.engine_status.set("BINANCE MOTORU ÇALIŞIYOR — CANLI VERİ GÜNCEL")
        elif process_running:
            self.engine_status.set(f"BINANCE MOTORU ÇALIŞIYOR — {status}")
        elif self.process is not None:
            return_code = self.process.poll()
            if return_code == 0:
                self.engine_status.set("Motor durdu")
            else:
                self.engine_status.set(f"Motor kapalı — çıkış kodu {return_code}")
        else:
            self.engine_status.set(f"Motor hazır — {status}")

        completed = int(state.get("bootstrap_completed") or 0)
        total = int(state.get("bootstrap_total") or 0)
        percent = int(state.get("bootstrap_progress_pct") or 0)
        successful = int(state.get("bootstrap_successful") or 0)
        errors = int(state.get("bootstrap_errors") or 0)
        skipped = int(state.get("bootstrap_skipped") or 0)
        retry_seconds = int(state.get("bootstrap_retry_seconds") or 0)
        connected_shards = int(state.get("websocket_connected_shards") or 0)
        total_shards = int(state.get("websocket_total_shards") or 0)
        message_ages = state.get("websocket_last_message_age_seconds")
        finite_ages = [
            float(age) for age in message_ages.values()
            if isinstance(age, (int, float)) and age >= 0
        ] if isinstance(message_ages, dict) else []
        live_age_text = f"{max(finite_ages):.0f} sn" if finite_ages else "henüz veri yok"
        warning_items = state.get("api_warnings")
        first_warning = warning_items[0] if isinstance(warning_items, list) and warning_items else None
        raw_error = (
            state.get("error") or state.get("settings_warning") or first_warning
            or state.get("universe_warning") or state.get("btcturk_universe_warning")
        )
        if not raw_error:
            error_text = "yok"
        else:
            normalized_error = " ".join(str(raw_error).split())
            upper_error = normalized_error.upper()
            if "WRONG_VERSION_NUMBER" in upper_error or "WRONG VERSION NUMBER" in upper_error:
                error_text = "TLS WRONG_VERSION_NUMBER"
            elif "TLS" in upper_error or "SSL" in upper_error:
                error_text = "TLS/SSL bağlantı hatası"
            elif "429" in upper_error or "418" in upper_error:
                error_text = "HTTP 429/418 hız sınırı"
            elif "TIMEOUT" in upper_error or "TIMED OUT" in upper_error:
                error_text = "Bağlantı zaman aşımı"
            else:
                error_text = normalized_error[:72] + ("…" if len(normalized_error) > 72 else "")
        if retry_seconds > 0:
            error_text += f" · tekrar {retry_seconds} sn"
        self.summary.set("\n".join((
            f"Başlangıç mum verileri: {completed}/{total} (%{percent})",
            f"WebSocket: {connected_shards}/{total_shards} bağlı · veri yaşı: {live_age_text}",
            f"Geçmiş: başarılı {successful}/{total} · hata {errors} · atlanan {skipped}",
            f"Hata: {error_text}",
        )))
        self.live_flow_var.set((
            f"motor / canlı akış: mum {completed}/{total} (%{percent}) · "
            f"websocket {connected_shards}/{total_shards} · veri yaşı {live_age_text} · "
            f"geçmiş {successful} başarılı / {errors} hata / {skipped} atlanan · "
            f"hata: {error_text}"
        ).lower())

        pair_count = state.get("common_pair_count")
        self.universe_count_var.set(
            f"{pair_count} parite" if isinstance(pair_count, int) else "Doğrulanmış sayı yok"
        )
        mode = str(state.get("universe_mode") or "—")
        mode_labels = {
            "SINGLE_ENGINE_LOCAL_LIST": "Yerel BtcTurk + Binance ortak evreni",
            "COMMON_VERIFIED": "Ortak evren doğrulandı",
            "CACHED_COMMON_FALLBACK": "Son doğrulanmış liste yedekte; güncel değil",
            "CACHED_LEGACY_UNIVERSE": "Eski ortak liste — tarihsel kaynak",
            "CACHED_BINANCE_SYMBOL_FALLBACK": "Kayıtlı ortak liste — Binance evreni güncel doğrulanmadı",
            "CACHED_LAST_VERIFIED_COMMON_UNIVERSE": "Son doğrulanmış ortak evren önbelleği — güçlü alarm kapalı",
            "BINANCE_ONLY_UNVERIFIED": "Binance-only yedek; BtcTurk eşleşmesi doğrulanmadı",
        }
        self.universe_mode_var.set(mode_labels.get(mode, mode))
        if mode == "CACHED_LAST_VERIFIED_COMMON_UNIVERSE":
            universe_stamp = (
                state.get("single_engine_universe_cache_generated_at_utc")
                or state.get("universe_generated_at_utc")
            )
        else:
            universe_stamp = state.get("universe_generated_at_utc")
        stamp_text = str(universe_stamp or "Henüz kayıt yok").replace("T", " ").replace("Z", " UTC")
        self.universe_timestamp_var.set(stamp_text[:32])
        local_summary = self._local_list_summary()
        list_stamp = state.get("btcturk_universe_generated_at_utc")
        if list_stamp:
            try:
                parsed_stamp = datetime.fromisoformat(str(list_stamp).replace("Z", "+00:00"))
                if parsed_stamp.tzinfo is None:
                    parsed_stamp = parsed_stamp.replace(tzinfo=timezone.utc)
                parsed_stamp = parsed_stamp.astimezone(timezone.utc)
                card_timestamp = parsed_stamp.strftime("%Y-%m-%d %H:%M:%S UTC")
            except (TypeError, ValueError, OverflowError):
                card_timestamp = str(list_stamp)
            self.btcturk_list_var.set("Son doğrulama: " + card_timestamp)
            local_summary = "Son doğrulama: " + card_timestamp
            if state.get("btcturk_universe_warning"):
                local_summary += " | UYARI: " + str(state.get("btcturk_universe_warning"))
        else:
            self.btcturk_list_var.set("Son doğrulama: kayıt yok")

        if mode == "CACHED_LAST_VERIFIED_COMMON_UNIVERSE":
            cache_age = state.get("single_engine_universe_cache_age_seconds")
            if isinstance(cache_age, (int, float)) and cache_age >= 0:
                if cache_age >= 86400:
                    cache_age_text = f"{cache_age / 86400:.1f} gün"
                elif cache_age >= 3600:
                    cache_age_text = f"{cache_age / 3600:.1f} saat"
                elif cache_age >= 60:
                    cache_age_text = f"{cache_age / 60:.1f} dakika"
                else:
                    cache_age_text = f"{cache_age:.0f} saniye"
            else:
                cache_age_text = "yaş bilinmiyor"
            cache_warning = (
                state.get("single_engine_universe_cache_warning")
                or state.get("universe_warning")
                or state.get("btcturk_universe_warning")
            )
            local_summary = (
                f"ORTAK EVREN YEDEK ÖNBELLEĞİ · Son doğrulama: {stamp_text[:32]} · "
                f"Önbellek yaşı: {cache_age_text} · Güçlü fırsat alarmı: KAPALI"
            )
            if cache_warning:
                local_summary += " · UYARI: " + " ".join(str(cache_warning).split())
            self.btcturk_list_var.set(
                f"Ortak evren yedek önbelleği · son doğrulama: {stamp_text[:32]} · "
                f"yaş: {cache_age_text} · güçlü alarm: KAPALI"
            )
        self.universe_summary.set(local_summary)
        pair_text = f"{pair_count} parite" if isinstance(pair_count, int) else "doğrulanmış sayı yok"
        self.universe_market_var.set("Binance Spot USDT")
        self.universe_pairs_var.set(f"{pair_text} · {self.universe_mode_var.get()}")
        self.universe_compact_var.set(
            f"Son evren kaydı: {stamp_text[:32]} · BtcTurk yerel liste durumu: {local_summary}"
        )
        btc_context_fresh = (
            live and state.get("btc_market_context_freshness") == "CANLI AKIŞ GÜNCEL"
        )
        self.btc_context_var.set(_btc_context_display_summary(
            state.get("btc_market_context"),
            current=btc_context_fresh,
            freshness=state.get("btc_market_context_freshness"),
        ))

        if live:
            self.engine_badge.configure(bg=STATUS_COLORS["green"], fg="#FFFFFF")
        elif process_running:
            self.engine_badge.configure(bg=STATUS_COLORS["yellow"], fg="#222222")
        elif status == "BAŞLATMA HATASI":
            self.engine_badge.configure(bg=STATUS_COLORS["red"], fg="#FFFFFF")
        else:
            self.engine_badge.configure(bg=THEME["panel_alt"], fg=THEME["text"])
        self._refresh_candidates()
        self._refresh_alert_lifecycle()

    def _copy_report_to_clipboard(self, report_text: str) -> bool:
        """Copy the readable Markdown report so it can be pasted into ChatGPT directly."""
        try:
            self.root.clipboard_clear()
            self.root.clipboard_append(report_text)
            self.root.update_idletasks()
            return True
        except tk.TclError as exc:
            self._append_log(f"Rapor metni panoya kopyalanamadı: {exc}")
            return False

    @staticmethod
    def _reveal_report_file(path: Path) -> bool:
        """Open Windows Explorer with the generated JSON report selected."""
        if os.name != "nt":
            return False
        try:
            subprocess.Popen(["explorer.exe", "/select,", str(path)])
            return True
        except OSError:
            try:
                os.startfile(str(path.parent))  # type: ignore[attr-defined]
                return True
            except OSError:
                return False

    def _create_report(self) -> None:
        state = self._state if isinstance(self._state, dict) else {}
        state_is_live = self._state_is_live()
        btc_context_current = (
            state_is_live and state.get("btc_market_context_freshness") == "CANLI AKIŞ GÜNCEL"
        )
        btc_strong_gate = assess_btc_strong_opportunity_gate(
            state.get("btc_market_context"),
            freshness=(
                state.get("btc_market_context_freshness")
                if btc_context_current else "ESKİ/EKSİK"
            ),
            require_measurements=True,
        )

        def redact_report_btc_metrics(safe_row: dict[str, Any], note: str) -> None:
            relative = safe_row.get("relative_strength_vs_btc_pct_points")
            safe_row["relative_strength_vs_btc_pct_points"] = (
                {str(key): None for key in relative}
                if isinstance(relative, dict) else
                {"15m": None, "1h": None, "4h": None}
            )
            correlations = safe_row.get("btc_return_correlation")
            cleaned_correlations = {}
            if isinstance(correlations, dict):
                for timeframe, measurement in correlations.items():
                    if isinstance(measurement, dict):
                        cleaned_correlations[str(timeframe)] = {
                            **measurement, "value": None, "current": False,
                            "status": "BTC canlı verisi eski/eksik",
                            "unavailable_reason": note,
                        }
                    else:
                        cleaned_correlations[str(timeframe)] = {
                            "value": None, "current": False,
                            "status": "BTC canlı verisi eski/eksik",
                            "unavailable_reason": note,
                        }
            safe_row["btc_return_correlation"] = cleaned_correlations
            safe_row["btc_market_context"] = {
                "status": "BTC VERİSİ ESKİ/EKSİK", "data_completeness": "EKSİK",
                "direction_score": 0.0, "critical_level_score": 0.0,
                "volatility_score": 0.0, "total_score": 0.0, "timeframes": {},
                "risk_warnings": [], "data_quality_warnings": [note],
            }
            safe_row["btc_market_context_freshness"] = "ESKİ/EKSİK"
            safe_row["btc_context_conflict_note"] = None
            findings = safe_row.get("findings")
            if isinstance(findings, list):
                safe_row["findings"] = [
                    item for item in findings
                    if not (
                        isinstance(item, str)
                        and (
                            "göreceli güç pozitif" in item.casefold()
                            or ("btc'ye göre" in item.casefold() and "göreceli güç" in item.casefold())
                            or "grup liderliği:" in item.casefold()
                        )
                    )
                ]
            missing = safe_row.get("missing_checks")
            missing_items = [item for item in missing if isinstance(item, str)] if isinstance(missing, list) else []
            missing_items.append(note)
            safe_row["missing_checks"] = sorted(set(missing_items))
            safe_row["group_leadership_score"] = 0
            safe_row["group_leadership_summary"] = None
            safe_row["group_leadership_basis"] = note
            safe_row["strong_opportunity_qualified"] = False
            existing_gates = safe_row.get("strong_opportunity_gate_reasons")
            existing_gates = (
                [item for item in existing_gates if isinstance(item, str)]
                if isinstance(existing_gates, list) else []
            )
            safe_row["strong_opportunity_gate_reasons"] = list(dict.fromkeys([
                *existing_gates,
                "BTC canlı bağlamı eski/eksik; güçlü fırsat ve alarm uygun değil.",
            ]))
            previous_decision = safe_row.get("final_decision") or safe_row.get("decision_class")
            if previous_decision:
                safe_row["last_known_final_decision"] = previous_decision
            safe_row["final_decision"] = None
            safe_row["decision_class"] = None
            safe_row["decision_reason"] = (
                "BTC canlı bağlamı eski/eksik; birleşik puan ve nihai karar yeniden doğrulanmalı."
            )
            safe_row["opportunity_score"] = None
            safe_row["score_0_100"] = None

        def report_candidate(row: dict[str, Any]) -> dict[str, Any]:
            safe_row = dict(row)
            row_live = state_is_live and row.get("data_freshness") == "CANLI AKIŞ GÜNCEL"
            candidate_btc_live = (
                btc_context_current
                and row.get("btc_market_context_freshness") == "CANLI AKIŞ GÜNCEL"
            )
            if row_live and candidate_btc_live:
                if not btc_strong_gate["eligible"]:
                    safe_row["strong_opportunity_qualified"] = False
                    if (
                        safe_row.get("final_decision") == "GÜÇLÜ FIRSAT"
                        or safe_row.get("decision_class") == "GÜÇLÜ FIRSAT"
                    ):
                        safe_row["final_decision"] = "ERKEN ADAY"
                        safe_row["decision_class"] = "ERKEN ADAY"
                        safe_row["decision_reason"] = (
                            "BTC ölçümleri güncel; ancak piyasa risk kapısı nedeniyle güçlü fırsat uygun değil."
                        )
                    existing_gates = safe_row.get("strong_opportunity_gate_reasons")
                    existing_gates = (
                        [item for item in existing_gates if isinstance(item, str)]
                        if isinstance(existing_gates, list) else []
                    )
                    safe_row["strong_opportunity_gate_reasons"] = list(dict.fromkeys([
                        *existing_gates, *btc_strong_gate["reasons"],
                    ]))
                return safe_row
            if row_live and not candidate_btc_live:
                redact_report_btc_metrics(
                    safe_row,
                    "BTC canlı bağlamı eski/eksik; göreceli güç, korelasyon ve grup liderliği güncel kabul edilmiyor.",
                )
                return safe_row
            btc_note = (
                "Rapor oluşturulurken genel motor canlı değildi; BTC göreceli güç, korelasyon "
                "ve grup liderliği güncel kabul edilemez."
            )
            relative = safe_row.get("relative_strength_vs_btc_pct_points")
            safe_row["relative_strength_vs_btc_pct_points"] = (
                {str(key): None for key in relative}
                if isinstance(relative, dict) else
                {"15m": None, "1h": None, "4h": None}
            )
            correlations = safe_row.get("btc_return_correlation")
            sanitized_correlations = {}
            if isinstance(correlations, dict):
                for timeframe, measurement in correlations.items():
                    if isinstance(measurement, dict):
                        sanitized_correlations[str(timeframe)] = {
                            **measurement,
                            "value": None,
                            "current": False,
                            "status": "BTC canlı verisi eski/eksik",
                            "unavailable_reason": btc_note,
                        }
                    else:
                        sanitized_correlations[str(timeframe)] = {
                            "value": None, "current": False,
                            "status": "BTC canlı verisi eski/eksik",
                            "unavailable_reason": btc_note,
                        }
            safe_row["btc_return_correlation"] = sanitized_correlations
            safe_row["btc_market_context"] = {
                "status": "BTC VERİSİ ESKİ/EKSİK",
                "data_completeness": "EKSİK",
                "direction_score": 0.0,
                "critical_level_score": 0.0,
                "volatility_score": 0.0,
                "total_score": 0.0,
                "timeframes": {},
                "risk_warnings": [],
                "data_quality_warnings": [btc_note],
            }
            findings = safe_row.get("findings")
            if isinstance(findings, list):
                safe_row["findings"] = [
                    item for item in findings
                    if not (
                        isinstance(item, str)
                        and (
                            "göreceli güç pozitif" in item.casefold()
                            or ("btc'ye göre" in item.casefold() and "göreceli güç" in item.casefold())
                            or "grup liderliği:" in item.casefold()
                        )
                    )
                ]
            missing = safe_row.get("missing_checks")
            missing_items = [
                item for item in missing if isinstance(item, str)
            ] if isinstance(missing, list) else []
            missing_items.append(btc_note)
            previous_decision = safe_row.get("final_decision") or safe_row.get("decision_class")
            if previous_decision:
                safe_row["last_known_final_decision"] = previous_decision
            previous_phase = safe_row.get("phase")
            if previous_phase in PHASE_COLORS and safe_row.get("last_known_phase") not in PHASE_COLORS:
                safe_row["last_known_phase"] = previous_phase
            safe_row["phase"] = None
            if safe_row.get("last_known_phase") in PHASE_COLORS:
                safe_row["state"] = "VERİ ESKİ/EKSİK — SON AŞAMA GÜNCEL TEYİT DEĞİL"
            safe_row.update({
                "data_freshness": "CANLI VERİ ESKİ/EKSİK",
                "btc_market_context_freshness": "ESKİ/EKSİK",
                "latest_price": None,
                "final_decision": None,
                "decision_class": None,
                "opportunity_score": None,
                "score_0_100": None,
                "decision_reason": "Veri eski/eksik; güncel karar doğrulanamadı.",
                "risk_plan": None,
                "btc_context_conflict_note": None,
                "group_leadership_score": 0,
                "group_leadership_summary": None,
                "group_leadership_basis": btc_note,
                "missing_checks": sorted(set(missing_items)),
            })
            return safe_row

        candidates = [report_candidate(row) for row in self._current_rows()]
        stamp = datetime.now().astimezone().strftime("%Y%m%d_%H%M%S")
        report_dir = ROOT / "reports"
        report_dir.mkdir(parents=True, exist_ok=True)
        json_path = report_dir / f"TEK_MOTOR_RAPORU_{stamp}.json"
        md_path = report_dir / f"TEK_MOTOR_RAPORU_{stamp}.md"
        bundle_path = report_dir / f"RAPOR_DEVIR_PAKETI_{stamp}.zip"
        selected_source = None
        selected_ids = self.candidate_tree.selection()
        if selected_ids:
            selected_source = self._rows_by_symbol.get(selected_ids[0])
        selected = report_candidate(selected_source) if isinstance(selected_source, dict) else None
        report_status = str(state.get("status", "bilinmiyor"))
        if report_status == "CANLI AKIŞ GÜNCEL" and not state_is_live:
            report_status = "CANLI VERİ ESKİ/EKSİK"
        state_for_report = dict(state)
        state_for_report["status"] = report_status
        state_for_report["candidates"] = candidates
        state_for_report["strong_alerts_enabled"] = (
            state.get("strong_alerts_enabled") is True
            and state_is_live
            and btc_strong_gate["eligible"]
        )
        state_for_report["btc_strong_alert_gate"] = btc_strong_gate
        state_for_report["live_state_verified"] = state_is_live
        btc_context_summary = _btc_market_context_summary(
            state.get("btc_market_context"), current=btc_context_current
        )
        state_for_report["btc_market_context_summary"] = btc_context_summary
        if not btc_context_current:
            # A report made without live confirmation must not retain old numeric BTC levels.
            state_for_report["btc_market_context"] = {
                "status": "BTC VERİSİ ESKİ/EKSİK",
                "data_completeness": "EKSİK",
                "direction_score": 0.0,
                "critical_level_score": 0.0,
                "volatility_score": 0.0,
                "total_score": 0.0,
                "timeframes": {},
                "risk_warnings": [],
                "data_quality_warnings": [
                    "Rapor anında BTC piyasa bağlamı güncel canlı veriyle doğrulanamadı."
                ],
                "stream_freshness": "ESKİ/EKSİK",
            }
            state_for_report["btc_market_context_freshness"] = "ESKİ/EKSİK"
            state_for_report["btc_market_context_warning"] = (
                "Rapor anında BTC piyasa bağlamı güncel canlı veriyle doğrulanamadı."
            )
        try:
            signal_history = historical_summary()
        except Exception as history_exc:
            signal_history = {
                "available": False,
                "note": f"Sinyal geçmişi okunamadı: {type(history_exc).__name__}: {history_exc}",
            }
        report = {
            "created_at_local": datetime.now().astimezone().isoformat(timespec="seconds"),
            "application_version": APP_VERSION,
            "motor": "Binance Spot",
            "btc_market_context_summary": btc_context_summary,
            "source_state": state_for_report,
            "selected_candidate": selected,
            "candidates": candidates,
            "signal_history": signal_history,
            "note": "Rapor araştırma amaçlıdır; emir veya kârlılık garantisi değildir.",
        }
        try:
            json_path.write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
            table = [
                "# FIRSAT-KONTROL PANELİ — Tek Motor Raporu",
                "",
                f"- Rapor zamanı: {report['created_at_local']}",
                f"- Uygulama sürümü: {APP_VERSION}",
                "- Motor: Binance Spot",
                f"- Veri durumu: {report_status}",
                f"- Ortak parite: {state.get('common_pair_count', 'bilinmiyor')}",
                f"- BTC piyasa bağlamı: {btc_context_summary}",
                (
                    "- BTC güçlü fırsat/alarm kapısı: AÇIK"
                    if btc_strong_gate["eligible"] else
                    "- BTC güçlü fırsat/alarm kapısı: KAPALI — "
                    + "; ".join(btc_strong_gate["reasons"])
                ),
                "",
                "| Parite | Nihai karar | Puan | Aşama | Veri durumu | Zaman dilimi | Fiyat (USDT) |",
                "|---|---|---:|---|---|---|---:|",
            ]
            for row in candidates:
                report_row = row
                fresh = report_row.get("data_freshness") == "CANLI AKIŞ GÜNCEL"
                phase = report_row.get("phase") if fresh and report_row.get("phase") in PHASE_COLORS else None
                old_phase = report_row.get("last_known_phase") or report_row.get("phase")
                phase_text = (phase if phase else
                              f"Son bilinen {old_phase} — güncel değil" if old_phase in PHASE_COLORS else "Güncel aşama yok")
                table.append(
                    "| " + " | ".join(str(value if value is not None else "—").replace("|", "/")
                    for value in (
                        row.get("symbol"),
                        _final_decision_text(report_row),
                        _opportunity_score_text(report_row),
                        phase_text,
                        report_row.get("data_freshness") or "bilinmiyor",
                        report_row.get("phase_timeframe"),
                        report_row.get("latest_price") if fresh else None,
                    )) + " |"
                )
            if selected:
                selected_fresh = (
                    selected.get("data_freshness") == "CANLI AKIŞ GÜNCEL"
                    and state_is_live
                )
                selected_phase = selected.get("phase") if selected_fresh else None
                selected_old_phase = selected.get("last_known_phase") or selected.get("phase")
                if selected_phase not in PHASE_COLORS:
                    selected_phase = (
                        f"Son bilinen {selected_old_phase} — güncel değil"
                        if selected_old_phase in PHASE_COLORS else "Güncel aşama yok"
                    )
                selected_decision_row = dict(selected)
                if not selected_fresh:
                    selected_decision_row["data_freshness"] = "CANLI VERİ ESKİ/EKSİK"
                selected_decision = _final_decision_text(selected_decision_row)
                selected_score = _opportunity_score_text(selected_decision_row)
                selected_plan = (
                    selected.get("risk_plan")
                    if selected_fresh and isinstance(selected.get("risk_plan"), dict)
                    else {}
                )

                def report_number(value: Any) -> str:
                    if (
                        isinstance(value, (int, float))
                        and not isinstance(value, bool)
                        and math.isfinite(float(value))
                    ):
                        return f"{float(value):g}"
                    return "—"

                entry_low = selected_plan.get("entry_zone_low")
                entry_high = selected_plan.get("entry_zone_high")
                entry_text = (
                    f"{report_number(entry_low)} – {report_number(entry_high)} USDT"
                    if report_number(entry_low) != "—" and report_number(entry_high) != "—"
                    else "—"
                )
                target_rows = (
                    selected_plan.get("targets", [])
                    if selected_plan.get("technical_targets_available") is True
                    else []
                )
                selected_targets = []
                for index, target in enumerate(target_rows[:3], start=1):
                    if not isinstance(target, dict):
                        continue
                    target_price = report_number(target.get("price"))
                    if target_price == "—":
                        continue
                    target_name = str(target.get("name") or f"Teknik hedef {index}")
                    target_basis = str(target.get("basis") or "teknik seviye")
                    selected_targets.append(f"{target_name}: {target_price} USDT ({target_basis})")
                targets_text = (
                    "; ".join(selected_targets)
                    if selected_fresh and selected_targets
                    else "Güncel teknik hedef yok"
                    if selected_fresh
                    else "Veri eski/eksik; güncel hedef yok"
                )
                net_rr = selected_plan.get("net_risk_reward")
                net_rr_text = (
                    f"{report_number(net_rr)}×"
                    if selected_plan.get("costs_included") is True and report_number(net_rr) != "—"
                    else "Doğrulanmadı"
                )
                decision_reason = (
                    selected.get("decision_reason")
                    if selected_fresh
                    else "Veri eski/eksik; güncel karar gerekçesi ve giriş planı üretilemez."
                ) or "Karar gerekçesi motor kaydında bulunmuyor."
                invalid_if = (
                    selected_plan.get("invalid_if") or "Planın geçersizlik koşulu kaydedilmemiş."
                    if selected_fresh else "Veri eski/eksik; geçersizlik koşulu güncel değil."
                )
                missing_checks = selected.get("missing_checks", [])
                missing_text = (
                    "; ".join(str(item) for item in missing_checks[:5])
                    if selected_fresh and isinstance(missing_checks, list) and missing_checks
                    else "Veri eski/eksik; güncel teyit durumu üretilemez."
                    if not selected_fresh else "Kayıtlı eksik teyit yok."
                )
                table.extend([
                    "", "## Seçilen coin", "",
                    f"- Parite: {selected.get('symbol', '—')}",
                    f"- Nihai karar: {selected_decision}",
                    f"- Fırsat puanı: {selected_score + '/100' if selected_score != '—' else '—'}",
                    f"- Karar gerekçesi: {decision_reason}",
                    f"- BTC korelasyonu: {_btc_correlation_summary(selected, current=selected_fresh)}",
                    f"- BTC/coin çelişkisi: {selected.get('btc_context_conflict_note') if selected_fresh and selected.get('btc_context_conflict_note') else 'kayıtlı risk çelişkisi yok veya güncel teyit yok'}",
                    f"- Grup liderliği: {(selected.get('group_leadership_summary') or selected.get('group_leadership_basis') or 'grup liderliği puanı yok') if selected_fresh else 'veri eski/eksik; güncel grup liderliği yok'}",
                    f"- Aşama: {selected_phase or selected_old_phase or 'AŞAMA YOK'}",
                    f"- Zaman dilimi: {selected.get('phase_timeframe') or '—'}",
                    f"- Binance fiyatı: {report_number(selected.get('latest_price')) if selected_fresh else '—'} USDT",
                    f"- Keşif yolu: {_discovery_path(selected)}",
                    f"- Veri durumu: {selected_decision_row.get('data_freshness', 'bilinmiyor')}",
                    f"- Giriş bölgesi: {entry_text}",
                    f"- Kırılım seviyesi: {report_number(selected_plan.get('breakout_level')) + ' USDT' if report_number(selected_plan.get('breakout_level')) != '—' else '—'}",
                    f"- Zarar durdurma: {report_number(selected_plan.get('stop_loss')) + ' USDT' if report_number(selected_plan.get('stop_loss')) != '—' else '—'}",
                    f"- Teknik hedefler: {targets_text}",
                    f"- Masraflar sonrası net risk/getiri: {net_rr_text}",
                    f"- Senaryoyu geçersiz kılan koşul: {invalid_if}",
                    f"- Eksik teyitler: {missing_text}",
                    "",
                ])
            history = report.get("signal_history") if isinstance(report.get("signal_history"), dict) else {}
            tracking = history.get("technical_plan_tracking")
            tracking = tracking if isinstance(tracking, dict) else {}
            mean_net = tracking.get("mean_estimated_net_return_pct")
            mean_net_text = (
                f"%{float(mean_net):g}"
                if isinstance(mean_net, (int, float)) and not isinstance(mean_net, bool)
                and math.isfinite(float(mean_net))
                else "hesaplanamadı"
            )
            mean_reference_change = tracking.get("mean_current_price_vs_entry_reference_pct")
            mean_reference_change_text = (
                f"%{float(mean_reference_change):+g}"
                if isinstance(mean_reference_change, (int, float)) and not isinstance(mean_reference_change, bool)
                and math.isfinite(float(mean_reference_change))
                else "hesaplanamadı"
            )
            mean_current_gross = tracking.get("mean_current_gross_return_pct")
            mean_current_gross_text = (
                f"%{float(mean_current_gross):+g}"
                if isinstance(mean_current_gross, (int, float)) and not isinstance(mean_current_gross, bool)
                and math.isfinite(float(mean_current_gross))
                else "hesaplanamadı"
            )
            mean_current_net = tracking.get("mean_current_estimated_net_return_pct")
            mean_current_net_text = (
                f"%{float(mean_current_net):+g}"
                if isinstance(mean_current_net, (int, float)) and not isinstance(mean_current_net, bool)
                and math.isfinite(float(mean_current_net))
                else "hesaplanamadı"
            )
            forward_return_lines = []
            forward_return_observations = history.get("forward_return_observations")
            if isinstance(forward_return_observations, dict):
                for field, label in (
                    ("return_30m_pct", "30 dk"),
                    ("return_1h_pct", "1 saat"),
                    ("return_4h_pct", "4 saat"),
                    ("return_24h_pct", "24 saat"),
                ):
                    details = forward_return_observations.get(field)
                    if not isinstance(details, dict):
                        continue
                    count = details.get("observations", 0)
                    mean_pct = details.get("mean_pct")
                    mean_pct_text = (
                        f"{float(mean_pct):+g}%"
                        if isinstance(mean_pct, (int, float)) and not isinstance(mean_pct, bool)
                        and math.isfinite(float(mean_pct))
                        else "hesaplanamadı"
                    )
                    timing = details.get("sampling_timing")
                    timing = timing if isinstance(timing, dict) else {}
                    delay = timing.get("mean_delay_seconds")
                    delay_text = (
                        f"ortalama örnekleme gecikmesi {float(delay):g} sn"
                        if isinstance(delay, (int, float)) and not isinstance(delay, bool)
                        and math.isfinite(float(delay))
                        else "örnekleme gecikmesi bilinmiyor"
                    )
                    forward_return_lines.append(
                        f"- {label} ileri fiyat gözlemi: {count} örnek, ortalama getiri {mean_pct_text}, {delay_text}"
                    )
            table.extend([
                "", "## Sinyal geçmişi ve teknik plan sonuçları", "",
                f"- Kaydedilen sinyal dönemleri: {history.get('episode_count', '—')}",
                f"- İzlenen teknik plan: {tracking.get('plan_count', 0)}",
                f"- İlk teknik hedef seviyesi gözlenen plan: {tracking.get('target_1_observed_count', 0)}",
                f"- Zarar durdurma seviyesi gözlenen plan: {tracking.get('stop_observed_count', 0)}",
                f"- 24 saatte giriş bölgesi gözlenmeyen plan: {tracking.get('entry_not_observed_count', 0)}",
                f"- Maliyet girdileriyle tahmini net sonuç sayısı: {tracking.get('estimated_net_return_observations', 0)}",
                f"- Tahmini net sonuç ortalaması: {mean_net_text}",
                f"- Mevcut fiyatın giriş referansına göre ortalama farkı: {mean_reference_change_text} ({tracking.get('current_price_reference_observations', 0)} plan; giriş gerçekleştiği anlamına gelmez)",
                f"- Girişi gözlenen planlarda anlık brüt sonuç ortalaması: {mean_current_gross_text} ({tracking.get('current_gross_return_observations', 0)} plan)",
                f"- Maliyet bilgisi bulunan planlarda anlık tahmini net sonuç ortalaması: {mean_current_net_text} ({tracking.get('current_estimated_net_return_observations', 0)} plan)",
                f"- Ölçüm notu: {tracking.get('note') or history.get('note') or 'Sinyal geçmişi henüz ölçüm üretmedi.'}",
                *forward_return_lines,
                "", "## Önemli not", "", "Bu rapor otomatik al-sat yapmaz ve fiyat hedefi/başarı garantisi vermez.",
            ])
            markdown_text = "\n".join(table) + "\n"
            md_path.write_text(markdown_text, encoding="utf-8")
            diagnostic = _write_transfer_bundle(report, json_path, md_path, bundle_path)
            settings_diag = diagnostic["settings_file"]
            clipboard_text = (
                f"FIRSAT-KONTROL PANELİ Sürüm {APP_VERSION} devir paketi: {bundle_path.name}\n"
                f"Rapor zamanı: {report['created_at_local']}\n"
                f"Veri durumu: {state.get('status', 'bilinmiyor')}\n"
                f"Filtreler: fan token={'geçerli' if state.get('fan_token_filter_valid') is True else 'geçersiz/teyitsiz'}, "
                f"sabit değerli={'geçerli' if state.get('stablecoin_filter_valid') is True else 'geçersiz/teyitsiz'}; "
                f"güçlü alarmlar={'açık' if state.get('strong_alerts_enabled') is True else 'kapalı'}.\n"
                "Ayrıntılar ZIP içindedir; uzun metni kopyalayıp yapıştırmayın, ZIP'i ekleyin."
            )
            copied_to_clipboard = self._copy_report_to_clipboard(clipboard_text)
            zip_selected = self._reveal_report_file(bundle_path)
            self._append_log(
                f"Rapor ve devir paketi oluşturuldu: {json_path.name}, {md_path.name}, {bundle_path.name}"
            )
            message_lines = [
                "Tam JSON raporu, okunabilir Markdown, tanı özeti, günlük eki ve SHA-256 bütünlük listesi tek ZIP dosyasında toplandı.",
                "",
                f"DEVİR ZIP: {bundle_path}",
                f"JSON: {json_path}",
                f"Markdown: {md_path}",
                "",
                "Bu sohbete yalnızca DEVİR ZIP dosyasını eklemeniz yeterli; uzun içeriği kopyalayıp yapıştırmanız gerekmez.",
                f"Ayar dosyası tanısı: {settings_diag.get('parse_status_now')} · fan listesi geçerli={settings_diag.get('fan_token_filter_valid_now')} · sabit değerli liste geçerli={settings_diag.get('stablecoin_filter_valid_now')}.",
            ]
            if copied_to_clipboard:
                message_lines.append("Kısa durum özeti panoya kopyalandı; tam rapor metni panoya kopyalanmadı.")
            else:
                message_lines.append("Kısa özet panoya kopyalanamadı; DEVİR ZIP dosyası eksiksiz oluşturuldu.")
            if zip_selected:
                message_lines.append("DEVİR ZIP dosyası Dosya Gezgini'nde seçildi.")
            else:
                message_lines.append(f"DEVİR ZIP dosyasının klasörü: {report_dir}")
            messagebox.showinfo("Rapor ve devir paketi hazır", "\n".join(message_lines), parent=self.root)
        except (OSError, TypeError, ValueError) as exc:
            self._append_log(f"Rapor oluşturulamadı: {exc}")
            messagebox.showerror("Rapor oluşturulamadı", str(exc), parent=self.root)

    def _handle_queues(self) -> None:
        while True:
            try:
                line = self.output_queue.get_nowait()
            except queue.Empty:
                break
            if line:
                self._append_log(line)
        while True:
            try:
                kind, payload = self.event_queue.get_nowait()
            except queue.Empty:
                break
            if kind == "list_ok":
                self.update_list_button.configure(state="normal")
                self._append_log(
                    f"Yerel BtcTurk listesi kaydedildi: {payload.get('count')} parite, "
                    f"zaman={payload.get('generated_at_utc')}."
                )
                if self.process is not None and self.process.poll() is None:
                    try:
                        REFRESH_PATH.write_text("refresh\n", encoding="utf-8")
                        self._append_log("Motorun sembol evreni yenilemesi istendi.")
                    except OSError as exc:
                        self._append_log(f"Motor evren yenileme isteği yazılamadı: {exc}")
            elif kind == "list_error":
                self.update_list_button.configure(state="normal")
                self._append_log(f"Yerel BtcTurk listesi güncellenemedi: {payload}")
                messagebox.showwarning(
                    "Parite listesi güncellenemedi", str(payload), parent=self.root
                )

    def _poll(self) -> None:
        if self.closing:
            return
        self._handle_queues()
        if self.process is not None and self.process.poll() is not None:
            code = self.process.returncode
            self.process = None
            self.stop_button.configure(state="disabled")
            self.start_button.configure(state="normal")
            self._stop_clock = _now_clock()
            self.stop_clock_var.set(f"Durdurma saati: {self._stop_clock}")
            self._append_log(f"Binance motoru kapandı; çıkış kodu={code}.")
        try:
            self._refresh_state()
        except Exception as exc:
            self._append_log(f"Panel güncelleme hatası: {exc}")
        self._poll_after_id = self.root.after(1000, self._poll)

    def _cancel_scheduled_callbacks(self, event: Any = None) -> None:
        """Cancel Tk after callbacks when the panel is destroyed, including in tests."""
        if event is not None and getattr(event, "widget", self.root) is not self.root:
            return
        for attribute in ("_titlebar_after_id", "_poll_after_id"):
            callback_id = getattr(self, attribute, None)
            if not callback_id:
                continue
            try:
                self.root.after_cancel(callback_id)
            except tk.TclError:
                pass
            setattr(self, attribute, None)

    def _on_close(self) -> None:
        self.closing = True
        self._cancel_scheduled_callbacks()
        if self.process is not None and self.process.poll() is None:
            try:
                STOP_PATH.write_text("stop\n", encoding="utf-8")
                self.process.wait(timeout=3)
            except (OSError, subprocess.TimeoutExpired):
                try:
                    self.process.terminate()
                except OSError:
                    pass
        self.root.destroy()


def main() -> None:
    root = tk.Tk()
    TekMotorPanel(root)
    root.mainloop()


if __name__ == "__main__":
    main()
